	static char USMID[] = "@(#)nupdate/unix/makedir.c	81.0	09/26/93 18:54:06";
/*      COPYRIGHT CRAY RESEARCH, INC.
 *      UNPUBLISHED -- ALL RIGHTS RESERVED UNDER
 *      THE COPYRIGHT LAWS OF THE UNITED STATES.
 */
#include "nupdate.h"

#ifdef sun
f_int makedir_(path)
#else
f_int MAKEDIR(path)
#endif
char *path;
{
	return (mkdir(path,0755));
}
