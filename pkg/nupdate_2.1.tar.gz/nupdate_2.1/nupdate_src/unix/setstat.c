	static char USMID[] = "@(#)nupdate/unix/setstat.c	81.0	09/26/93 18:54:06";
/*      COPYRIGHT CRAY RESEARCH, INC.
 *      UNPUBLISHED -- ALL RIGHTS RESERVED UNDER
 *      THE COPYRIGHT LAWS OF THE UNITED STATES.
 */
#include <sys/types.h>
#include "nupdate.h"

#ifdef sun
f_int setstat_(path,ts)
#else
f_int SETSTAT(path,ts)
#endif
char *path;
f_int *ts;
{
	struct utimbuf {
		time_t actime;
		time_t modtime;
	};
	struct utimbuf buf;

	buf.actime = *ts;
	buf.modtime = *ts;
	return (utime(path,&buf));
}
