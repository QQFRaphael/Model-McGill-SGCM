#include "nupdate.h"

hpalloc_(addr, len, err, abrt)
f_pointer *addr;
f_int *len;
f_int *err;
f_int *abrt;
{
        extern char *malloc();

        if ((*addr = (f_pointer)malloc(*len*8)) == 0)
        {
                if (*abrt==1)
                       abort(*abrt);
                else
                       *err = 1;
        }
        else
                *err = 0;
}
