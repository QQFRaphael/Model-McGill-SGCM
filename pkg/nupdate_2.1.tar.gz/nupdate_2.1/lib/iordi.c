/*      This routine takes one doubleprecision number, and
        one integer, ors them together and reutnrs an
        integer value.
 */

#include "nupdate.h"

f_int
iordi_(d1,i2)
f_int d1[], *i2;
{
#ifdef __little__endian__
        int b=0;
#else
        int b=1;
#endif
        return (d1[b] | *i2);
}
