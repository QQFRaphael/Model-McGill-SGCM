#include <stdio.h>
#include "nupdate.h"

/*    fread.c        */

f_int
fread_(ptr, size, n, fp)
char *ptr;
f_int *size, *n;
FILE **fp;
{
	return((f_int)fread(ptr,
           (int)*size, (int)*n, *fp));
}
