#include <stdio.h>
#include "nupdate.h"

/*    fseek.c        */

f_int
fseek_(fp, offset, whence)
FILE **fp;
f_int *offset, *whence;
{
	return((f_int)fseek(*fp, (long)(*offset), (int)(*whence)));
}
