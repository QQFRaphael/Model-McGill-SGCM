#include <stdio.h>
#include "nupdate.h"

/*    fdopen.c        */

f_pointer
fdopen_(fildes, type)
f_int *fildes;
char *type;
{
	FILE *fdopen();
	return((f_pointer)fdopen((int )*fildes, type));
}
