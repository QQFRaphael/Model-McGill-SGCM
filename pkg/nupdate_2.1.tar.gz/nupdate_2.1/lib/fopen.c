#include <stdio.h>
#include "nupdate.h"

/*    fopen.c        */

f_pointer
fopen_(name, mode)
char *name, *mode;
{
	FILE *fopen();
	return((f_pointer)fopen(name, mode));
}
