#include <sys/types.h>
#include <time.h>

#include "nupdate.h"

f_double date_()

{
	struct tm *mtm;
	time_t clock;
	extern struct tm *localtime();
	extern time_t time();
	union {
		f_double res;
		char res1[8];
	} result;

	clock = time(0);
	mtm = localtime(&clock);
	sprintf(result.res1,"%.2d/%.2d/%.2d",mtm->tm_mon+1,
           mtm->tm_mday,(mtm->tm_year)%100);
	return (result.res);
}
