#include "nupdate.h"

hpdeallc_(addr, err, abrt)
f_pointer *addr;
f_int *err;
f_int *abrt;
{
        extern void free();
        free(*addr);
}
