	static char USMID[] = "@(#)sunlib/dshiftli.c	0.1	03/26/90 11:58:06";

/*
	dshiftli.  This routine takes an integer value,
	shifts it left VALUE bits, and returns a
	double precision value.
*/

#include "nupdate.h"

f_double
dshiftli_(i1,value)
f_int *i1, *value;
{

#ifdef __little__endian__
        int a=1,b=0;
#else
        int a=0,b=1;
#endif

	union
	{
		f_double res;
		f_int res1[2];
	} foo;

	if (*value==32)
	{
		foo.res1[a] = *i1;
		foo.res1[b] = 0;
	}
	else if (*value>32)
        {
		/*
			shifting left more than 32 bits 0s out the low order
			bits.
		*/
		foo.res1[b] = 0;
		foo.res1[a] = *i1<<(*value-32);
        }
	else if (*value == 0)
	{
		/*
			Shifting left exactly 0 bits sets the
			high order bits to 0, and sets the lower order
			bits to the integer value.
		*/
		foo.res1[a] = 0;
		foo.res1[b] = *i1;
	}
        else
        {
		/*
			shifting left fewer than 32 bits.
		*/
		foo.res1[b] = *i1<<*value;
		foo.res1[a] = (unsigned)*i1>>(32-*value);
	}
	return (foo.res);
}
