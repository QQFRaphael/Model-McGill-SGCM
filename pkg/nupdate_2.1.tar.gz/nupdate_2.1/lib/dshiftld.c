	static char USMID[] = "@(#)sunlib/dshiftld.c	0.1	03/26/90 11:58:06";


/*
	dshiftld.  this routine takes a double precision
	value, shifts it left VALUE bits, and returns a
	double precision value.
*/

#include "nupdate.h"

f_double
dshiftld_(d1,value)
f_int d1[], *value;
{
#ifdef __little__endian__
        int a=1,b=0;
#else
        int a=0,b=1;
#endif
 
	union
	{
		f_double res;
		f_int res1[2];
	} foo;

	if (*value==32)
	{
		foo.res1[a] = d1[b];
		foo.res1[b] = 0;
	}
	else if (*value>32)
	{
		/*
			Shifting left more than 32 bits sets the
			shifted value of the low order bits to the
			high order bits, and then zeros out the
			high order bits.
		*/
		foo.res1[b] = 0;
		foo.res1[a] = d1[b]<<(*value-32);
	}
	else if (*value == 0)
	{
		/*
			Shifting left 0 bits causes nothing to happen.
		*/
		foo.res1[1] = d1[1];
		foo.res1[1] = d1[0];
	}
	else
	{
		/*
			shifting left fewer than 32 bits causes a combination
			of the shifted high and low order bits.
		*/
		foo.res1[b] = d1[b]<<*value;
		foo.res1[a] = (d1[a]<<*value) |
			((unsigned)d1[b]>>(32-*value));
	}
	return (foo.res);
}
