#include <sys/types.h>
#include <time.h>
#include "nupdate.h"
f_double clock_()

{
	struct tm *mtm;
	time_t clock;
	extern struct tm *localtime();
	extern time_t time();
	union {
		f_double res;
		char res1[8];
	} result;

	clock = time(0);
	mtm = localtime(&clock);
	sprintf(result.res1,"%.2d:%.2d:%.2d",mtm->tm_hour,
           mtm->tm_min,mtm->tm_sec);
	return (result.res);
}
