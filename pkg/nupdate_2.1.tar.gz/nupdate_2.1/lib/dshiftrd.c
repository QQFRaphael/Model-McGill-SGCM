	static char USMID[] = "@(#)sunlib/dshiftrd.c	0.1	03/26/90 11:58:06";

/*
	dshiftrd.  This routine takes a double precision
	value, shifts it right VALUE bits, and returns a
	double precision value.
*/

#include "nupdate.h"

f_double
dshiftrd_(d1,value)
f_int d1[], *value;
{
#ifdef __little__endian__
        int a=1,b=0;
#else
        int a=0,b=1;
#endif
 
	union
	{
		f_double res;
		f_int res1[2];
	} foo;



	if (*value==32)
	{
		foo.res1[b] = d1[a];
		foo.res1[a] = 0;
	}
	else if (*value>32)
	{
		/*
			shifting right more than 32 bits sets the shifted value
			of the high order bits to the low order bits.
		*/

		foo.res1[a] = 0;
		foo.res1[b] = (unsigned)d1[a]>>(*value-32);
	}
	else if (*value == 0)
	{
		/*
			Shifting right exactly 0 bits does nothing.
		*/
		foo.res1[0] = d1[0];
		foo.res1[1] = d1[1];
	}
	else
	{
		/*
			shifting right fewer than 32 bits causes a combination
			of the shifted low order and high order bits.
		*/
		foo.res1[b] = (d1[a]<<(32-*value)) |
			((unsigned)d1[b]>>*value);
		foo.res1[a] = (unsigned)d1[a]>>*value;
	}
	return (foo.res);
}
