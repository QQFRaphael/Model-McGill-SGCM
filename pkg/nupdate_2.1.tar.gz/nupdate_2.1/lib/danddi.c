/*      This routine takes one double precision number and
        one integer number, ands them together and returns
        a doubleprecision value.
 */

#include "nupdate.h"

f_double
danddi_(d1,i2)
f_int d1[], *i2;
{
#ifdef __little__endian__
        int a=1,b=0;
#else
        int a=0,b=1;
#endif
        union {
                 f_double res;
                 f_int res1[2];
              } foo;

              foo.res1[a] = 0;
              foo.res1[b] = d1[b] & *i2;
              return (foo.res);
}
