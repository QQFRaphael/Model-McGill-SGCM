	static char USMID[] = "@(#)nmodex/unix/getwho.c	81.0	09/26/93 18:39:01";
	/*
		COPYRIGHT CRAY RESEARCH, INC.
		UNPUBLISHED -- ALL RIGHTS RESERVED UNDER
		THE COPYRIGHT LAWS OF THE UNITED STATES.
	*/
#include <pwd.h>
#include <sys/types.h>
#ifdef sun
double getwho_()
#else
long GETWHO()
#endif

{
        union {
#ifdef _32BIT
		double res;
#else
		long res;
#endif
		char res1[8];
	} result;
	int i, j, length, uid;

	struct passwd *getpwuid();
	struct passwd *temp;



	uid = getuid();
	temp = getpwuid(uid);
	if (!temp)
	{
		for (i=0;i<8;i++)
			result.res1[i] = ' ';
		return(result.res);
	}

	length = strlen(temp->pw_name);
	if (length > 8) length = 8;
	for (i=0;i<strlen(temp->pw_name);i++)
	{
		result.res1[i] = temp->pw_name[i];
	}
	for (j=i;j<8;j++)
	{
		result.res1[j] = ' ';
	}
	return(result.res);
}
