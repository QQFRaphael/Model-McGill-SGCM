	static char USMID[] = "@(#)plcopy/scmtonupd.c	81.0	09/26/93 19:03:21";
/*	COPYRIGHT CRAY RESEARCH, INC.
 *	UNPUBLISHED -- ALL RIGHTS RESERVED UNDER
 *	THE COPYRIGHT LAWS OF THE UNITED STATES.
 */
#include <stdio.h>
#include "pl.h"

int numdecks=0, nummods=0;
struct list *decks=0, *mods = 0;
struct list *decktail = 0, *modstail = 0;

#ifdef SUN
char *nupdate="/usr/local/bin/nupdate";
#else
char *nupdate="/bin/nupdate";
#endif


scmtonupd(scmpl, updatepl, qstr, qlen)
char *scmpl, *updatepl, *qstr;
int qlen;
{

	extern char buffer[];
	char *deckname, *namespace, *filelist;
	char filename[512], ufilename[512];

	int c, i, lastid, namesplen, nchar, nw, skip, start;

	FILE *fp, *filefp, *outfp;

	struct idt ident;
	struct plinfot plinfo;
	struct list *p;
	struct
	{
		unsigned part1:32;
		unsigned part2:32;
	}one_word;

	extern int isscm(), processdk();
	extern FILE *createfile();

	if (!isscm(scmpl))
	{
		exit (1);
	}

	if (dir(updatepl))
	{
		fprintf(stderr, "plcopy:  %s already exists\n",updatepl);
		exit (1);
	}

	/*  Now, read in the files one at a time, and do the conversion.  */
	filelist = (char *)malloc(strlen(scmpl)+16);
	strcpy(filelist,scmpl);
	strcat(filelist,"/.SCM/.filelist");
	fp = fopen(filelist,"r");
	if (!fp)
	{
		fprintf(stderr,"plcopy:  Cannot open %s\n",filelist);
		exit (1);
	}

	while (fgets(buffer,512,fp))
	{
		/*  get rid of the new line  */
		skip = 0;
		buffer[strlen(buffer)-1] = '\0';
		if (qstr)
		{
			if (strncmp(qstr,buffer,qlen) == 0)
			{
				/*  This is a match, the deck name is the same as the
				    path to be skipped, trim the deckname.   */
				deckname = buffer+qlen;
				if (strlen(deckname) <= 0) skip = 1;
			}
			else
			{
				skip = 1;
			}
		}
		else
		{
			deckname = buffer;
		}

		if (!skip)
		{
			strcpy(filename,scmpl);
			strcat(filename,"/.SCM/");
			strcat(filename,buffer);
			strcat(filename,".m");

			filefp = fopen(filename,"r");
			if (!filefp)
			{
				fprintf(stderr, "plcopy:  Cannot open %s\n",filename);
				exit (1);
			}
			strcpy(ufilename,updatepl);
			strcat(ufilename,"/");
			strcat(ufilename,deckname);
			strcat(ufilename,".u");
			outfp = createfile(ufilename);
			if (!outfp)
			{
				fprintf(stderr, "plcopy:  Cannot create %s\n",ufilename);
				exit (1);
			}
			if (!processdk(deckname,filefp,outfp))
			{
				fprintf(stderr, "plcopy:  Error processing deck %s\n",filename);
				exit (1);
			}
			if (fclose(outfp) != 0)
			{
				fprintf(stderr, "plcopy:  Cannot close %s\n",ufilename);
				exit (1);
			}
			(void) fclose(filefp);
		}
	}

	/*  Done reading the old pl, and processing the decks.  Now, create the
	    TIDENT table.  */
	ident.un1 = 0;
	ident.dkdw1 = 0;
	ident.dkdw = 0;
	ident.lang = 0;
	ident.ns = 1;

	ident.t = ident.m = ident.un2 = ident.y = 0;
	ident.c = 1;
	ident.pos = 0;
	ident.un3 = 0;
	ident.timestamp = time(0);

	/*  process the decks first, and then the identifiers.  */
	p = decks;
	if (!p)
	{
		fprintf(stderr, "plcopy:  No decks in %s\n",scmpl);
		exit (1);
	}
	nw = (strlen(p->name)+7)/8;
	namespace = (char *)malloc(nw*8);
	namesplen = 0;

	strcpy(ufilename,updatepl);
	strcat(ufilename,"/.TIDENT");
	outfp = fopen(ufilename,"w+");
	if (!outfp)
	{
		fprintf(stderr, "plcopy:  Cannot open %s\n",ufilename);
		exit (1);
	}


	/*  Set type to 1 for DECK  */
	ident.type = 1;
	lastid = -1;
	while (p)
	{
		ident.namelen = strlen(p->name);
		ident.hash = hash(p->name,ident.namelen);
		ident.id = p->id;
		if (p->id > lastid) lastid = p->id;
		ident.offset = namesplen+1;

		/*  Compute the number of words in the name  */
		nw = (ident.namelen+7)/8;
		namespace = (char *)realloc(namespace,(namesplen+nw)*8);

		/*  Copy the name from the pointer to the namespace  */
		for (i=0;i<ident.namelen;i++)
		{
			namespace[i+(namesplen*8)] = p->name[i];
		}

		/*  Now, pad with nulls  */

		nchar = (nw*8)-ident.namelen;

		/*  Determine the place to start padding with nulls  */
		start = (nw+namesplen-1)*8 + (8-nchar);
		for (i=0;i<nchar;i++)
		{
			namespace[i+start] = '\0';
		}
		namesplen = namesplen+nw;

		/*  Now, write out the tident entry  */
		if (fwrite(&ident,sizeof(struct idt),1,outfp) != 1)
		{
			fprintf(stderr, "plcopy:  Cannot write to %s\n",ufilename);
			exit (1);
		}
		p = p->next;
	}

	ident.type = 0;
	p = mods;
	while (p)
	{
		ident.namelen = strlen(p->name);
		ident.hash = hash(p->name,ident.namelen);
		ident.id = p->id;
		if (p->id > lastid) lastid = p->id;
		ident.offset = namesplen+1;

		/*  Compute the number of words in the name  */
		nw = (ident.namelen+7)/8;
		namespace = (char *)realloc(namespace,(namesplen+nw)*8);

		/*  Copy the name from the pointer to the namespace  */
		for (i=0;i<ident.namelen;i++)
		{
			namespace[i+(namesplen*8)] = p->name[i];
		}

		/*  Now, pad with nulls  */

		nchar = (nw*8)-ident.namelen;

		/*  Determine the place to start padding with nulls  */
		start = (nw+namesplen-1)*8 + (8-nchar);
		for (i=0;i<nchar;i++)
		{
			namespace[i+start] = '\0';
		}
		namesplen = namesplen+nw;

		/*  Now, write out the tident entry  */
		if (fwrite(&ident,sizeof(struct idt),1,outfp) != 1)
		{
			fprintf(stderr, "plcopy:  Cannot write to %s\n",ufilename);
			exit (1);
		}
		p = p->next;
	}

	one_word.part1 = ftell(outfp)/8;
	one_word.part2 = namesplen;
	if (fwrite(&one_word,8,1,outfp) != 1)
	{
		fprintf(stderr, "plcopy:  Cannot write to %s\n",ufilename);
		exit (1);
	}

	/*  Now, write out the name space table  */
	if (fwrite(namespace,8,namesplen,outfp) != namesplen)
	{
		fprintf(stderr, "plcopy:  Cannot write to %s\n",ufilename);
		exit (1);
	}

	/*  Now, create and write out the plinfo table.  */
	plinfo.cc = 'd';
	plinfo.mc = '*';
	plinfo.pmc = 1;
	plinfo.un1 = 0;
	plinfo.idcnt = numdecks+nummods;
	plinfo.idpos = 0;
	get_date(plinfo.date);
	plinfo.idpart1 = 0;
	plinfo.idpart2 = lastid;
	plinfo.un2 = 0;
	plinfo.un3 = 0;

	/*  Set default data width to variable length  */
	plinfo.dw = 0;
	plinfo.pldw = 80;
	for (i=0;i<7;i++)
		plinfo.unused[i] = '\0';

	strncpy(plinfo.signature,"HIST OK ",8);

	if (fclose(outfp) != 0)
	{
		fprintf(stderr, "plcopy:  Cannot close %s\n",ufilename);
		exit (1);
	}

	/*  Open the .PLINFO file  */
	strcpy(ufilename,updatepl);
	strcat(ufilename,"/.PLINFO");
	outfp = fopen(ufilename,"w+");
	if (!outfp)
	{
		fprintf(stderr, "plcopy:  Cannot open %s\n",ufilename);
		exit (1);
	}

	if (fwrite(&plinfo,sizeof(struct plinfot),1,outfp) != 1)
	{
		fprintf(stderr, "plcopy:  Cannot write to %s\n",ufilename);
		exit (1);
	}
}
