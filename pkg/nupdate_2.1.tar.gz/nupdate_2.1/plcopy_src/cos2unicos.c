	static char USMID[] = "@(#)plcopy/cos2unicos.c	81.0	09/26/93 19:03:21";
/*	COPYRIGHT CRAY RESEARCH, INC.
 *	UNPUBLISHED -- ALL RIGHTS RESERVED UNDER
 *	THE COPYRIGHT LAWS OF THE UNITED STATES.
 */
#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include "pltabs.h"

cos2unicos(inpl, outpl, makeold)
char *inpl, *outpl;
int makeold;

{

	/*  This routine creates a unicospl from a COS format
	    pl.  It reads from inpl, and writes to outpl.  The
	    inpl is presumed to have been disposed from COS with
	    a DF=TR or DF=UNICOS.  This routine needs to handle
	    either case.  */


	char inbuff[513*8], outbuff[513*8];
	char *cw, *hdrwrds=0, *namespce;

	int endpos, i, next, nsectors, nw, numdecks, nummods, offset, oldpl, pos;
	int tidcnt, tidptr, tmodptr, tptr, varlen;

	long namesplen, lastid, ts;

	struct plinfot plinfo;
	struct newplinfot newplinfo;
	struct oldidt *tident, *modids;
	struct newidt *newtident, *newmodids;
	union cardheader hdr;
	struct
	{
		unsigned part1:32;
		unsigned part2:32;
	}one_word;

	FILE *infp, *outfp;

	extern char *getcw();
	extern long hash();
	extern int validpl();





	infp = fopen(inpl,"r b");
	if (!infp)
	{
		fprintf(stderr,"plcopy: unable to open file %s\n",inpl);
		exit (1);
	}


	/*  Position to the end of the PL.  If an EOD is not found, then
	    the dispose format is DF=TR, and there is junk at the
	    end of the PL.  */


	(void) fseek(infp,0,2);
	endpos = ftell(infp);


	/*  Position to the beginning of the LAST sector, and scan forward until
	    an EOD or the end of the file is found  */
	nsectors = (endpos/8)/512;
	if (fseek(infp,(nsectors*8*512),0) != 0)
	{
		fprintf(stderr, "plcopy:  unable to seek in file %s\n",inpl);
		exit (1);
	}
	if (nsectors*512*8 == endpos)
	{
		/*  Back up one sector in order to read forward.  */
		if (fseek(infp,-512*8,1) != 0)
		{
			fprintf(stderr, "plcopy:  unable to seek in file %s\n",inpl);
			exit (1);
		}
	}
	/*  This is not at an eod, scan forward to find it  */
	cw = getcw(infp, &next);
	while (strcmp(cw,"eod"))
	{
		/*  Position next*8 words forward  */
		if (fseek(infp,(next*8),1) != 0)
		{
			fprintf(stderr, "plcopy:  invalid COS format PL.\n");
			fprintf(stderr, "         Dispose with DF=UNICOS\n");
			exit (1);
		}
		cw = getcw(infp,&next);
	}

	/*  Back up 9 words to INFO table.  */
	if (fseek(infp,-(9*8),1) != 0)
	{
		fprintf(stderr, "plcopy:  unable to position to PLINFO table in %s\n",inpl);
		exit (1);
	}

	/*  Read in the plinfo table  */
	if (fread((char *)&plinfo,sizeof(struct plinfot),1,infp) != 1)
	{
		fprintf(stderr, "plcopy:  unable to read from input pl %s\n",inpl);
		exit (1);
	}

	/*  validate plinfo table  */
	oldpl = validinfo(&plinfo);
	if (!oldpl && makeold)
	{
		fprintf(stderr, "plcopy:  unable to create old pl structure from new pl\n");
		exit (1);
	}
	if (oldpl && plinfo.dw >256 )
	{
		varlen = 1;
	}
	else
	{
		varlen = 0;
	}

	nsectors = plinfo.idpos/511+1;
	plinfo.idpos = plinfo.idpos + nsectors-1;
	if (fseek(infp,(plinfo.idpos*8),0) != 0)
	{
		fprintf(stderr, "plcopy:  unable to seek to idpos in %s\n",inpl);
		exit (1);
	}
	cw = getcw(infp,&next);

	tidcnt = plinfo.idcnt;

	if (oldpl)
	{
		readoids(&tident,&modids,&numdecks,&nummods,tidcnt,infp,inpl,&next);
		sortold(tident,numdecks);
	}
	else
	{
		readnewids(&newtident,&newmodids,&numdecks,&nummods,tidcnt,
			infp,inpl,&next);
		sortnew(newtident,numdecks);
		/*  Read in the name space  */
		if (next == 0)
		{
			cw = getcw(infp,&next);
			if (strcmp(cw,"eor") || next < 1)
			{
				fprintf(stderr,"plcopy:  invalid control word in %s\n",inpl);
				exit (1);
			}
		}
		if (fread((char *)&one_word,8,1,infp) != 1)
		{
			fprintf(stderr, "plcopy:  unable to read from %s\n",inpl);
			exit (1);
		}
		next--;
		namesplen = one_word.part2;
		namespce = (char *)malloc(namesplen*8+1);
		offset = 0;
		while (offset<namesplen)
		{
			if (next==0)
			{
				cw=getcw(infp,&next);
				if (strcmp(cw,"bcw") || next < 1)
				{
					fprintf(stderr,"plcopy:  invalid control word in %s\n",inpl);
					exit (1);
				}
			}
			else
			{
				if (fread(&namespce[offset*8],8,next,infp) != next)
				{
					fprintf(stderr, "plcopy:  unable to read from %s\n",inpl);
					exit (1);
				}
				offset = offset+next;
				next = 0;
			}
		}
	}

	/*  rewind the pl and initialize for processing of each deck  */
	rewind(infp);
	outfp = fopen(outpl,"w+b");
	if (!outfp)
	{
		fprintf(stderr, "plcopy:  unable to open file %s\n",outpl);
		exit (1);
	}
	cw = getcw(infp, &next);
	tidptr = 0;
	while (tidptr < numdecks)
	{
		/*  Compute the position in the new PL for the tident table  */
		if (oldpl)
		{
			tident[tidptr].part2.flags.pos = ftell(outfp)/8;
		}
		else
		{
			newtident[tidptr].part2.flags.pos = ftell(outfp)/8;
		}
		cw = "   ";
		while (strcmp(cw,"eof"))
		{
			/*  Read in the header words  */
			while (next==0 && strcmp(cw,"eof"))
			{
				cw = getcw(infp, &next);
			}
			if (strcmp(cw,"eof"))
			{
				cw = "   ";
				/*  The end of this deck is not found  */
				if (fread(hdr.stuff,8,1,infp) != 1)
				{
					fprintf(stderr, "plcopy:  unable to read from %s\n",inpl);
					unlink(outpl);
					exit (1);
				}
				next--;
				if (hdr.flags.hdc>1)
				{
					/*  There are header words to be read in  */
					nw = (hdr.flags.hdc+2)/4;
					hdrwrds = (char *)malloc(8*nw);
					if (next==0)
					{
						/*  Read in the cw, and then the hdrwrds  */
						cw = getcw(infp,&next);
						if (strcmp(cw,"bcw") || next<nw)
						{
							fprintf(stderr, "plcopy:  invalid cw sequence\n");
							unlink(outpl);
							exit (1);
						}
					}
					if (next>=nw)
					{
						/*  Read in the hdrwrds.  There is no cw  */
						if (fread(hdrwrds,8,nw,infp) != nw)
						{
							fprintf(stderr, "plcopy:  unable to read from %s\n",
								inpl);
							unlink(outpl);
							exit (1);
						}
						next = next-nw;
					}
					else
					{
						/*  Read in a number of words, then the cw, then
						    the rest of the header words  */
						if (fread(hdrwrds,8,next,infp) != next)
						{
							fprintf(stderr, "plcopy:  unable to read from %s\n",
								inpl);
							unlink(outpl);
							exit (1);
						}
						tptr = next*8;
						nw = nw-next;
						cw = getcw(infp, &next);
						if (strcmp(cw,"bcw") || next<nw)
						{
							fprintf(stderr, "plcopy:  invalid cw sequence\n");
							unlink(outpl);
							exit (1);
						}
						if (fread(&hdrwrds[tptr],8,nw,infp) != nw)
						{
							fprintf(stderr, "plcopy:  unable to read from %s\n",
								inpl);
							unlink(outpl);
							exit (1);
						}
					}
				}
				/*  the header words are read in.  read in the card  */
				tptr = 0;
				while (strcmp(cw,"eor"))
				{
					if (next==0)
					{
						cw=getcw(infp,&next);
						if (strcmp(cw,"eod")==0 || strcmp(cw,"eof")==0)
						{
							fprintf(stderr, "plcopy:  premature end of deck\n");
							(void) fclose(outfp); unlink(outpl);
							exit (1);
						}
					}
					else
					{
						if (fread(&inbuff[tptr],8,next,infp) != next)
						{
							fprintf(stderr, "plcopy:  unable to read from %s\n",
								inpl);
							unlink(outpl);
							exit (1);
						}
						tptr = tptr+next*8;
						next = 0;
					}
				}
				/*  The header is read, and so is the card.  Decompress it  */
				inbuff[tptr] = '\0';
				decomp(varlen,inbuff,outbuff);
				hdr.flags.charcnt = strlen(outbuff);
				for (i=0;i<8;i++)
					outbuff[hdr.flags.charcnt+i] = ' ';
				if (fwrite(hdr.stuff,8,1,outfp) != 1)
				{
					fprintf(stderr, "plcopy:  unable to write to %s\n",outpl);
					unlink(outpl);
					exit (1);
				}
				if (hdrwrds)
				{
					nw = (hdr.flags.hdc+2)/4;
					if (fwrite(hdrwrds,8,nw,outfp) != nw)
					{
						fprintf(stderr, "plcopy:  unable to write to %s\n",
							outpl);
						unlink(outpl);
						exit (1);
					}
					free(hdrwrds); hdrwrds=0;
				}
				nw = (hdr.flags.charcnt+7)/8;
				if (fwrite(outbuff,8,nw,outfp) != nw)
				{
						fprintf(stderr, "plcopy:  unable to write to %s\n",
							outpl);
						unlink(outpl);
						exit (1);
				}
			}
		}
		/*  the entire deck is written out, write out a zero word  */
		one_word.part1 = 0;
		one_word.part2 = 0;
		if (fwrite((char *)&one_word,8,1,outfp) != 1)
		{
			fprintf(stderr, "plcopy:  unable to write to %s\n",
				outpl);
			unlink(outpl);
			exit (1);
		}
		tidptr++;
	}
	/*  All decks are written out, write out the TIDENT table  */
	plinfo.idpos = ftell(outfp)/8;
	if (makeold)
	{
		if (numdecks>0)
		{
			if (fwrite((char *)tident,sizeof(struct oldidt),numdecks,outfp) != numdecks)
			{
				fprintf(stderr, "plcopy:  unable to write to %s\n",
					outpl);
				unlink(outpl);
				exit (1);
			}
		}
		if (nummods>0)
		{
			if (fwrite((char *)modids,sizeof(struct oldidt),nummods,outfp) != nummods)
			{
				fprintf(stderr, "plcopy:  unable to write to %s\n",
					outpl);
				unlink(outpl);
				exit (1);
			}
		}
		if (fwrite((char *)&plinfo,sizeof(struct plinfot),1,outfp) != 1)
		{
			fprintf(stderr, "plcopy:  unable to write to %s\n",
				outpl);
			unlink(outpl);
			exit (1);
		}
	}
	else if (oldpl)
	{
		/*  Convert the old TIDENT into a new format TIDENT  */
		newtident = (struct newidt *)malloc((numdecks+nummods)*sizeof(struct newidt));
		tidptr = offset = 0;
		namespce = (char *)malloc(8*(numdecks+nummods)+1);
		ts = time(0);
		lastid = -1;
		while (tidptr<numdecks)
		{
			if (tident[tidptr].name[7] != '\0')
			{
				newtident[tidptr].part1.flags.namelen = 8;
			}
			else
			{
				newtident[tidptr].part1.flags.namelen = strlen(tident[tidptr].name);
			}
			newtident[tidptr].part1.flags.hash =
				hash(tident[tidptr].name,newtident[tidptr].part1.flags.namelen);
			newtident[tidptr].part1.flags.newun1 = 0;
			newtident[tidptr].part1.flags.dkdw1 = plinfo.dw>>5;
			newtident[tidptr].part1.flags.dkdw = plinfo.dw & 0x1F;
			newtident[tidptr].part1.flags.lang = 0;
			if (varlen)
			{
				newtident[tidptr].part1.flags.ns = 1;
			}
			else
			{
				newtident[tidptr].part1.flags.ns = 0;
			}
			newtident[tidptr].part1.flags.offset = offset+1;
			newtident[tidptr].part2.flags.type = tident[tidptr].part2.flags.type;
			newtident[tidptr].part2.flags.t = tident[tidptr].part2.flags.t;
			newtident[tidptr].part2.flags.m = tident[tidptr].part2.flags.m;
			newtident[tidptr].part2.flags.un1 = tident[tidptr].part2.flags.un1;
			newtident[tidptr].part2.flags.y = tident[tidptr].part2.flags.y;
			newtident[tidptr].part2.flags.c = tident[tidptr].part2.flags.c;
			newtident[tidptr].part2.flags.id = tident[tidptr].part2.flags.id;
			newtident[tidptr].part2.flags.pos = tident[tidptr].part2.flags.pos;
			newtident[tidptr].part3.flags.un2 = 0;
			newtident[tidptr].part3.flags.timestamp = ts;
			for (i=0;i<8;i++)
				namespce[(offset*8)+i] = tident[tidptr].name[i];
			offset++;
			if (strncmp(plinfo.id,tident[tidptr].name,8)==0)
			{
				lastid = tident[tidptr].part2.flags.id;
			}
			tidptr++;
		}
		tmodptr = 0;
		while (tmodptr<nummods)
		{
			if (modids[tmodptr].name[7] != '\0')
			{
				newtident[tidptr].part1.flags.namelen = 8;
			}
			else
			{
				newtident[tidptr].part1.flags.namelen = strlen(modids[tmodptr].name);
			}
			newtident[tidptr].part1.flags.hash =
				hash(modids[tmodptr].name,newtident[tidptr].part1.flags.namelen);
			newtident[tidptr].part1.flags.newun1 = 0;
			newtident[tidptr].part1.flags.dkdw1 = 0;
			newtident[tidptr].part1.flags.dkdw = 0;
			newtident[tidptr].part1.flags.lang = 0;
			newtident[tidptr].part1.flags.ns = 0;
			newtident[tidptr].part1.flags.offset = offset+1;
			newtident[tidptr].part2.flags.type = modids[tmodptr].part2.flags.type;
			newtident[tidptr].part2.flags.t = modids[tmodptr].part2.flags.t;
			newtident[tidptr].part2.flags.m = modids[tmodptr].part2.flags.m;
			newtident[tidptr].part2.flags.un1 = modids[tmodptr].part2.flags.un1;
			newtident[tidptr].part2.flags.y = modids[tmodptr].part2.flags.y;
			newtident[tidptr].part2.flags.c = modids[tmodptr].part2.flags.c;
			newtident[tidptr].part2.flags.id = modids[tmodptr].part2.flags.id;
			newtident[tidptr].part2.flags.pos = modids[tmodptr].part2.flags.pos;
			newtident[tidptr].part3.flags.un2 = 0;
			newtident[tidptr].part3.flags.timestamp = ts;
			for (i=0;i<8;i++)
				namespce[(offset*8)+i] = modids[tmodptr].name[i];
			offset++;
			if (strncmp(plinfo.id,modids[tmodptr].name,8)==0)
			{
				lastid = modids[tmodptr].part2.flags.id;
			}
			tmodptr++;
			tidptr++;
		}
		/*  Now write out the new tident and the name space  */
		if (fwrite((char *)newtident,sizeof(struct newidt),numdecks+nummods,outfp) !=
			numdecks+nummods)
		{
			fprintf(stderr, "plcopy:  unable to write to %s\n",
				outpl);
			unlink(outpl);
			exit (1);
		}

		/*  Write out the position in the file and the length of the namespace */
		nw = numdecks+nummods;
		one_word.part1 = ftell(outfp)/8;
		one_word.part2 = nw;
		if (fwrite((char *)&one_word,8,1,outfp) != 1)
		{
			fprintf(stderr, "plcopy:  unable to write to %s\n",
				outpl);
			unlink(outpl);
			exit (1);
		}
		/*  Write out the name space table  */
		if (fwrite(namespce,8,nw,outfp) != nw)
		{
			fprintf(stderr, "plcopy:  unable to write to %s\n",
				outpl);
			unlink(outpl);
			exit (1);
		}

		/*  convert and write out the plinfo table  */
		newplinfo.cc = 'd';
		newplinfo.mc = plinfo.mc;
		newplinfo.pmc = plinfo.pmc;
		newplinfo.un1 = 0;
		newplinfo.idcnt = plinfo.idcnt;
		newplinfo.idpos = plinfo.idpos;
		strncpy(newplinfo.date,plinfo.date,8);
		newplinfo.idpart1 = 0;
		if (lastid<0)
		{
			fprintf(stderr, "plcopy:  unable to find lastid in pl, set to 0\n");
			newplinfo.idpart2 = 0;
		}
		else
		{
			newplinfo.idpart2 = lastid;
		}
		newplinfo.un2 = plinfo.un2;
		newplinfo.un3 = plinfo.un3;
		newplinfo.dw = 0;
		newplinfo.pldw = plinfo.dw;
		strncpy(newplinfo.unused,plinfo.unused,8);
		strncpy(newplinfo.signature,plinfo.signature,8);
		if (fwrite((char *)&newplinfo,sizeof(struct newplinfot),1,outfp) != 1)
		{
			fprintf(stderr, "plcopy:  unable to write to %s\n",
				outpl);
			unlink(outpl);
			exit (1);
		}
	}
	else
	{
		/*  Making the new PL format from the new PL format  */
		if (fwrite((char *)newtident,sizeof(struct newidt),numdecks,outfp) != numdecks)
		{
			fprintf(stderr, "plcopy:  unable to write to %s\n",outpl);
			unlink(outpl);
			exit (1);
		}
		if (fwrite((char *)newmodids,sizeof(struct newidt),nummods,outfp) != nummods)
		{
			fprintf(stderr, "plcopy:  unable to write to %s\n",outpl);
			unlink(outpl);
			exit (1);
		}
		/*  Write out the position in the file and the length of the namespace  */
		one_word.part1 = ftell(outfp)/8;
		one_word.part2 = namesplen;
		if (fwrite((char *)&one_word,8,1,outfp) != 1)
		{
			fprintf(stderr, "plcopy:  unable to write to %s\n",outpl);
			unlink(outpl);
			exit (1);
		}
		/*  Write out the name space table  */
		if (fwrite(namespce,8,namesplen,outfp) != namesplen)
		{
			fprintf(stderr, "plcopy:  unable to write to %s\n",outpl);
			unlink(outpl);
			exit (1);
		}
		/*  Write out the plinfo  */
		if (fwrite((char *)&plinfo,sizeof(struct plinfot),1,outfp) != 1)
		{
			fprintf(stderr, "plcopy:  unable to write to %s\n",outpl);
			unlink(outpl);
			exit (1);
		}
	}
	if (fclose(outfp) != 0)
	{
		fprintf(stderr, "plcopy:  unable to close %s\n",
			outpl);
		unlink(outpl);
		exit (1);
	}
	return;
}
