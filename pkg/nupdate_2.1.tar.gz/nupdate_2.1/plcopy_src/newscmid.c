	static char USMID[] = "@(#)plcopy/newscmid.c	81.0	09/26/93 19:03:21";
/*	COPYRIGHT CRAY RESEARCH, INC.
 *	UNPUBLISHED -- ALL RIGHTS RESERVED UNDER
 *	THE COPYRIGHT LAWS OF THE UNITED STATES.
 */
#include <stdio.h>
newscmid(buffer,newid1,newid2,basedeck,deck)
char buffer[];
char **newid1, **newid2;
char *basedeck, *deck;

{

	extern char *direct;

	char *tptr, *id, *id2, *seq;
	char newseq[10];

	int i;

	extern char *usmdep(), *strrchr();




	tptr = &buffer[3];
	while (tptr[0] == ' ')tptr++;
	id = tptr;
	tptr = strrchr(id,',');
	if (tptr)
	{
		tptr[0] = '\0';
		id2 = tptr+1;
	}
	else
	{
		id2 = 0;
	}
	tptr = strrchr(id,'.');
	if (!tptr)
	{
		fprintf(stderr, "plcopy:  Error in format of mod\n");
		fprintf(stderr, "%s\n",buffer);
		return(0);
	}
	tptr[0] = '\0';
	seq = tptr+1;
	if (strcmp(id,deck)==0)
	{
		/*  This is the same as the deck, substitute the
		    full deck name and subtract 1 from the sequence number */
		*newid1 = (char *)malloc(strlen(basedeck)+1+strlen(seq)+1);
		strcpy(*newid1,basedeck);
		strcat(*newid1,".");
		i = atol(seq)-1;
		if (i<=0)
		{
			fprintf(stderr, "plcopy :  *I %s.1 not convertable\n",
				id);
			return(0);
		}
		sprintf(newseq,"%d",i);
		strcat(*newid1,newseq);
	}
	else
	{
		/*  copy the old id */
		*newid1 = 0;
		if (direct)
		{
			/*  Check if this mod was added after the permapply  */
			*newid1 = usmdep(id,seq,deck);
		}
		if (!*newid1)
		{
			*newid1 = (char *)malloc(strlen(id)+1+strlen(seq)+1);
			strcpy(*newid1,id);
			strcat(*newid1,".");
			strcat(*newid1,seq);
		}
	}
	if (id2)
	{
		tptr = strrchr(id2,'.');
		if (!tptr)
		{
			fprintf(stderr, "plcopy:  Error in format of mod\n");
			fprintf(stderr, "%s\n",buffer);
			return(0);
		}
		tptr[0] = '\0';
		seq = tptr+1;
		if (strcmp(id2,deck)==0)
		{
			/*  This is the same as the deckname, substitute the
			    basedeck name and subtract 1 from the sequence number */
			*newid2 = (char *)malloc(strlen(basedeck)+1+strlen(seq)+1);
			strcpy(*newid2,basedeck);
			strcat(*newid2,".");
			i = atol(seq)-1;
			if (i<=0)
			{
				fprintf(stderr, "plcopy :  *I %s.1 not convertable\n",
					id2);
				return(0);
			}
			sprintf(newseq,"%d",i);
			strcat(*newid2,newseq);
		}
		else
		{
			*newid2 = 0;
			if (direct)
			{
				*newid2 = usmdep(id2,seq,deck);
			}
			if (!*newid2)
			{
				*newid2 = (char *)malloc(strlen(id2)+1+strlen(seq)+1);
				strcpy(*newid2,id2);
				strcat(*newid2,".");
				strcat(*newid2,seq);
			}
		}
	}
	else
	{
		*newid2 = 0;
	}
	return(1);
}
