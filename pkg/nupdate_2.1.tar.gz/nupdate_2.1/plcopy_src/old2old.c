	static char USMID[] = "@(#)plcopy/old2old.c	81.0	09/26/93 19:03:21";
/*	COPYRIGHT CRAY RESEARCH, INC.
 *	UNPUBLISHED -- ALL RIGHTS RESERVED UNDER
 *	THE COPYRIGHT LAWS OF THE UNITED STATES.
 */
#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include "pltabs.h"

old2old(inpl, outpl)
char *inpl, *outpl;

{

	/*
		This routine converts an old format UNICOS PL to
		an old cos format PL.
	*/

	char name[1000];
	char *tptr;

	int bufptr, enddeck, lastcw, lasteof, lastrcw, i;
	int numdecks=0, nummods=0, nw, nw2, oldpl, padnw, tidcnt, tidptr, ubc=0;
	int varlen;
	long numbcws;

	struct
	{
		union
		{
			struct
			{
				char cc;
				char mc;
				unsigned pmc:1;
				unsigned un1:1;
				unsigned idcnt:14;
				unsigned idpos:32;
			}flags;
			char stuff[8];
		}word1;
		char date[8];
		char id[8];
		union
		{
			struct
			{
				unsigned un2:32;
				unsigned un3:12;
				unsigned dw:10;
				unsigned pldw:10;
			}flags;
			char stuff[8];
		}word4;
		char unused[8];
		char signature[8];
	}plinfo;

	struct oldidt tempid, *tident, *modids;

	union
	{
		struct
		{
			unsigned part1:32;
			unsigned part2:32;
		}flags;
		char stuff[8];
	}one_word;

	union cardheader hdr;
	union
	{
		struct cw control;
		char stuff[8];
	}buffer[512];

	

	FILE *infp, *outfp;

	extern int validpl();
	extern char *strchr();




	/*  Open up the file and position to the PL table  */
	infp = fopen(inpl,"r b");
	if (!infp)
	{
		fprintf(stderr,"plcopy:  Unable to open file %s\n",inpl);
		exit (1);
	}
	(void) fseek(infp,-48,2);

	if (fread((char *)&plinfo,48,1,infp) != 1)
	{
		fprintf(stderr, "plcopy:  unable to read from file %s\n",inpl);
		exit (1);
	}

	/*  validate plinfo table  */
	oldpl = validinfo(&plinfo);
	if (!oldpl)
	{
		fprintf(stderr, "plcopy:  PL not in old format\n",inpl);
		exit (1);
	}
	if (plinfo.word4.flags.pldw > 256)
	{
		varlen = 1;
	}
	else
	{
		varlen = 0;
		if (plinfo.word4.flags.dw ==0)
		{
			plinfo.word4.flags.pldw = 80;
			plinfo.word4.flags.dw = 72;
		}
	}

	/*  Read in the TIDENT and sort it  */
	if (fseek(infp,(plinfo.word1.flags.idpos*8),0) != 0)
	{
		fprintf(stderr, "plcopy:  Unable to position in file %s\n",inpl);
		exit (1);
	}

	tidcnt = plinfo.word1.flags.idcnt;

	tident = (struct oldidt *)malloc(tidcnt*sizeof(struct oldidt));
	modids = (struct oldidt *)malloc(tidcnt*sizeof(struct oldidt));

	while (tidcnt > 0)
	{
		if (fread((char *)&tempid, sizeof (struct oldidt),1,infp) != 1)
		{
			fprintf(stderr, "plcopy:  unable to read from file %s\n",inpl);
			exit (1);
		}
		if (tempid.part2.flags.type != 0)
		{
			/*  This is a deck, copy into tident[numdecks]  */
			tident[numdecks] = tempid;
			numdecks++;
		}
		else
		{
			modids[nummods] = tempid;
			nummods++;
		}
		tidcnt--;
	}
	sortold(tident,numdecks);

	/*  Go through and read in every record, building control words as we go  */

	outfp = fopen(outpl,"w b");
	if (!outfp)
	{
		fprintf(stderr, "plcopy:  Cannot open %s\n",outpl);
		exit (1);
	}

	lastcw = tidptr = 0;

	/*  Build a BCW word  */
	buildbcw(buffer,0);
	lastcw=0;
	numbcws = lasteof = lastrcw = bufptr = 1;
	
	while (tidptr<numdecks)
	{
		if (fseek(infp,(tident[tidptr].part2.flags.pos*8),0) != 0)
		{
			fprintf(stderr, "plcopy:  Unable to position in file %s\n",inpl);
			unlink(outpl);
			exit (1);
		}

		/*  Set the position in the OLD tident  */
		tident[tidptr].part2.flags.pos = ftell(outfp)/8+bufptr-numbcws;

		enddeck = 0;
		while (!enddeck)
		{
			/*  Read in the header  */
			if (fread(hdr.stuff,8,1,infp) != 1)
			{
				fprintf(stderr, "plcopy:  Cannot read %s\n",name);
				unlink(outpl);
				exit (1);
			}

			if (hdr.flags.flags == 0 && hdr.flags.charcnt == 0 &&
				hdr.flags.seq1 == 0 && hdr.flags.seq2 == 0 &&
				hdr.flags.hdc == 0 && hdr.flags.id == 0)
			{
				enddeck = 1;
			}
			else
			{
				/*  Determine the number of words to read  */
				nw = (hdr.flags.charcnt+7)/8 + (hdr.flags.hdc+2)/4;
				if (varlen)
				{
				   ubc = ((((hdr.flags.charcnt+7)/8)*8)-hdr.flags.charcnt)*8;
				   padnw = 0;
				}
				else
				{
				   ubc = 0;
				   /*  Determine pad, minus header words  */
				   padnw = (plinfo.word4.flags.pldw+7)/8-(hdr.flags.charcnt+7)/8;
				}
				hdr.flags.charcnt = 0;
				for (i=0;i<8;i++)
					buffer[bufptr].stuff[i] = hdr.stuff[i];
				bufptr++;
				if (bufptr+nw <= 512)
				{
					/*  Read the entire record into buffer */
					if (fread(&buffer[bufptr],8,nw,infp) != nw)
					{
						fprintf(stderr, "plcopy:  Cannot read from %s\n",
							name);
						unlink(outpl);
						exit (1);
					}
					bufptr = bufptr+nw;
					/*  Set the unused bits to 0  */
					for (i=8-(ubc/8);i<8;i++)
						buffer[bufptr-1].stuff[i] = '\0';
					/*  Determine whether the RCW will fit */
					if (bufptr==512)
					{
						write_buff(buffer,lastcw,outfp,outpl);
						buildbcw(buffer,numbcws);
						bufptr = 1;
						lastcw = 0;
						numbcws++;
					}
				}
				else
				{
					/*  Read in part of a record, write out the buffer, and
					read in the rest of the record  */
					nw2 = 512-bufptr;
					if (fread(&buffer[bufptr],8,nw2,infp) != nw2)
					{
						fprintf(stderr, "plcopy:  Cannot read from %s\n",
							name);
						unlink(outpl);
						exit (1);
					}
					write_buff(buffer,lastcw,outfp,outpl);
					buildbcw(buffer,numbcws);
					bufptr = 1;
					lastcw = 0;
					numbcws++;
					nw = nw-nw2;
					if (fread(&buffer[bufptr],8,nw,infp) != nw)
					{
						fprintf(stderr, "plcopy:  Cannot read from %s\n",
							name);
						unlink(outpl);
						exit (1);
					}
					bufptr = bufptr+nw;
					/*  Set the unused bits to 0  */
					for (i=8-(ubc/8);i<8;i++)
						buffer[bufptr-1].stuff[i] = '\0';
				}
				if (!varlen)
				{
					/*  pad the rest of the buffer with blanks, and
				    	write out the buffer */
					if (bufptr+padnw <= 512)
					{
						/*  Pad the entire buffer with blanks */
						for (i=0;i<padnw;i++)
							strncpy(buffer[bufptr+i].stuff,"        ",8);
						bufptr = bufptr+padnw;
					}
					else
					{
						nw = 512-bufptr;
						for (i=0;i<nw;i++)
							strncpy(buffer[bufptr+i].stuff,"        ",8);
						write_buff(buffer,lastcw,outfp,outpl);
						buildbcw(buffer,numbcws);
						bufptr = 1;
						lastcw = 0;
						numbcws++;
						padnw = padnw-nw;
						for (i=0;i<padnw;i++)
							strncpy(buffer[bufptr+i].stuff,"        ",8);
						bufptr = bufptr+padnw;
					}
				}
				if (bufptr==512)
				{
					/*  This word needs to be written out  */
					write_buff(buffer,lastcw,outfp,outpl);
					buildbcw(buffer,numbcws);
					bufptr = 1;
					lastcw = 0;
					numbcws++;
				}

				/*  Build an RCW  */
				buildcw(buffer,bufptr,8,numbcws,lasteof,lastrcw,lastcw);
				buffer[bufptr].control.ubc = ubc;
				ubc = 0;
				lastcw = bufptr;
				bufptr++;
				lastrcw = numbcws;

				if (bufptr==512)
				{
					/*  This word needs to be written out  */
					write_buff(buffer,lastcw,outfp,outpl);
					buildbcw(buffer,numbcws);
					bufptr = 1;
					lastcw = 0;
					numbcws++;
				}
			}

			if (bufptr==512)
			{
				/*  This word needs to be written out  */
				write_buff(buffer,lastcw,outfp,outpl);
				buildbcw(buffer,numbcws);
				bufptr = 1;
				lastcw = 0;
				numbcws++;
			}
		}
		/*  We are at the end of the deck, create a EOF  */
		buildcw(buffer,bufptr,14,numbcws,lasteof,lastrcw,lastcw);
		lastcw = bufptr;
		bufptr++;
		lasteof = numbcws;
		if (bufptr==512)
		{
			/*  This word needs to be written out  */
			write_buff(buffer,lastcw,outfp,outpl);
			buildbcw(buffer,numbcws);
			bufptr = 1;
			lastcw = 0;
			numbcws++;
		}
		tidptr++;
	}

	/*  At the end of all decks, copy the tident into the buffer */
	plinfo.word1.flags.idpos = ftell(outfp)/8+bufptr-numbcws;
	for (tidptr=0;tidptr<numdecks;tidptr++)
	{
		if (bufptr==512)
		{
			/*  This word needs to be written out  */
			write_buff(buffer,lastcw,outfp,outpl);
			buildbcw(buffer,numbcws);
			bufptr = 1;
			lastcw = 0;
			numbcws++;
		}
		/*  There are two scenarios  */
		if (bufptr<511)
		{
			/*  copy both words for this entry  */
			for (i=0;i<8;i++)
				buffer[bufptr].stuff[i] = tident[tidptr].name[i];
			bufptr++;
			for (i=0;i<8;i++)
				buffer[bufptr].stuff[i] = tident[tidptr].part2.stuff[i];
			bufptr++;
		}
		else
		{
			/*  copy 1 word for this entry, start a new block, and copy the last  */
			for (i=0;i<8;i++)
				buffer[bufptr].stuff[i] = tident[tidptr].name[i];
			write_buff(buffer,lastcw,outfp,outpl);
			buildbcw(buffer,numbcws);
			bufptr = 1;
			lastcw = 0;
			numbcws++;
			for (i=0;i<8;i++)
				buffer[bufptr].stuff[i] = tident[tidptr].part2.stuff[i];
			bufptr++;
		}
	}
	for (tidptr=0;tidptr<nummods;tidptr++)
	{
		if (bufptr==512)
		{
			/*  This word needs to be written out  */
			write_buff(buffer,lastcw,outfp,outpl);
			buildbcw(buffer,numbcws);
			bufptr = 1;
			lastcw = 0;
			numbcws++;
		}
		/*  There are two scenarios  */
		if (bufptr<511)
		{
			/*  copy both words for this entry  */
			for (i=0;i<8;i++)
				buffer[bufptr].stuff[i] = modids[tidptr].name[i];
			bufptr++;
			for (i=0;i<8;i++)
				buffer[bufptr].stuff[i] = modids[tidptr].part2.stuff[i];
			bufptr++;
		}
		else
		{
			/*  copy 1 word for this entry, start a new block, and copy the last  */
			for (i=0;i<8;i++)
				buffer[bufptr].stuff[i] = modids[tidptr].name[i];
			write_buff(buffer,lastcw,outfp,outpl);
			buildbcw(buffer,numbcws);
			bufptr = 1;
			lastcw = 0;
			numbcws++;
			for (i=0;i<8;i++)
				buffer[bufptr].stuff[i] = modids[tidptr].part2.stuff[i];
			bufptr++;
		}
	}

	/*  Now, lastly, create an EOR, EOF sequence, and copy in the plinfo table  */
	buildcw(buffer,bufptr,8,numbcws,lasteof,lastrcw,lastcw);
	lastcw = bufptr;
	bufptr++;
	lastrcw=numbcws;
	if (bufptr==512)
	{
		write_buff(buffer,lastcw,outfp,outpl);
		buildbcw(buffer,numbcws);
		bufptr = 1;
		lastcw = 0;
		numbcws++;
	}
	buildcw(buffer,bufptr,14,numbcws,lasteof,lastrcw,lastcw);
	lastcw = bufptr;
	bufptr++;
	lasteof = numbcws;
	if (bufptr==512)
	{
		write_buff(buffer,lastcw,outfp,outpl);
		buildbcw(buffer,numbcws);
		bufptr = 1;
		lastcw = 0;
		numbcws++;
	}
	/*  Now, copy in the plinfo words  */

	for (i=0;i<8;i++)
		buffer[bufptr].stuff[i] = plinfo.word1.stuff[i];
	bufptr++;
	if (bufptr==512)
	{
		write_buff(buffer,lastcw,outfp,outpl);
		buildbcw(buffer,numbcws);
		bufptr = 1;
		lastcw = 0;
		numbcws++;
	}

	strncpy(buffer[bufptr].stuff,plinfo.date,8);
	bufptr++;
	if (bufptr==512)
	{
		write_buff(buffer,lastcw,outfp,outpl);
		buildbcw(buffer,numbcws);
		bufptr = 1;
		lastcw = 0;
		numbcws++;
	}

	strncpy(buffer[bufptr].stuff,plinfo.id,8);
	bufptr++;
	if (bufptr==512)
	{
		write_buff(buffer,lastcw,outfp,outpl);
		buildbcw(buffer,numbcws);
		bufptr = 1;
		lastcw = 0;
		numbcws++;
	}

	for (i=0;i<8;i++)
		buffer[bufptr].stuff[i] = plinfo.word4.stuff[i];
	bufptr++;
	if (bufptr==512)
	{
		write_buff(buffer,lastcw,outfp,outpl);
		buildbcw(buffer,numbcws);
		bufptr = 1;
		lastcw = 0;
		numbcws++;
	}

	for (i=0;i<8;i++)
		buffer[bufptr].stuff[i] = plinfo.unused[i];
	bufptr++;
	if (bufptr==512)
	{
		write_buff(buffer,lastcw,outfp,outpl);
		buildbcw(buffer,numbcws);
		bufptr = 1;
		lastcw = 0;
		numbcws++;
	}

	for (i=0;i<8;i++)
		buffer[bufptr].stuff[i] = plinfo.signature[i];
	bufptr++;
	if (bufptr==512)
	{
		write_buff(buffer,lastcw,outfp,outpl);
		buildbcw(buffer,numbcws);
		bufptr = 1;
		lastcw = 0;
		numbcws++;
	}

	/*  Create an EOR, EOF and EOD  */
	buildcw(buffer,bufptr,8,numbcws,lasteof,lastrcw,lastcw);
	lastcw = bufptr;
	lastrcw=numbcws;
	bufptr++;
	if (bufptr==512)
	{
		write_buff(buffer,lastcw,outfp,outpl);
		buildbcw(buffer,numbcws);
		bufptr = 1;
		lastcw = 0;
		numbcws++;
	}

	buildcw(buffer,bufptr,14,numbcws,lasteof,lastrcw,lastcw);
	lastcw = bufptr;
	bufptr++;
	lasteof = numbcws;
	if (bufptr==512)
	{
		write_buff(buffer,lastcw,outfp,outpl);
		buildbcw(buffer,numbcws);
		bufptr = 1;
		lastcw = 0;
		numbcws++;
	}

	buildcw(buffer,bufptr,15,numbcws,lasteof,lastrcw,lastcw);
	buffer[bufptr].control.fwi = 0;

	if (fwrite(buffer,8,bufptr+1,outfp) != bufptr+1)
	{
		fprintf(stderr, "plcopy:  Cannot write to %s\n",outpl);
		unlink(outpl);
		exit (1);
	}
	(void) fclose(outfp);
	return;
}
