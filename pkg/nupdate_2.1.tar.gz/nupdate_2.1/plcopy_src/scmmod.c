	static char USMID[] = "@(#)plcopy/scmmod.c	81.0	09/26/93 19:03:21";
/*	COPYRIGHT CRAY RESEARCH, INC.
 *	UNPUBLISHED -- ALL RIGHTS RESERVED UNDER
 *	THE COPYRIGHT LAWS OF THE UNITED STATES.
 */
#include <stdio.h>

scmmod(inmod,outmod,qstr,qlen)
char *inmod, *outmod, *qstr;
int qlen;

{

	extern char buffer[];
	char buffer2[BUFSIZ];

	char *basedeck, *deck, *inmodid, *newid1, *newid2, *outmodid, *tptr;

	int lastcomment;

	FILE *infp, *outfp;

	extern char *strrchr();




	/*  Ensure that the output mod is not the same as the input mod  */
	inmodid = strrchr(inmod,'/');
	if (inmodid)
		inmodid++;
	else
		inmodid = inmod;

	outmodid = strrchr(outmod,'/');
	if (outmodid)
		outmodid++;
	else
		outmodid = outmod;

	/* open the files  */
	infp = fopen(inmod,"r");
	if (!infp)
	{
		fprintf(stderr, "plcopy:  unable to open file %s\n",inmod);
		exit (1);
	}
	outfp = fopen(outmod,"r");
	if (outfp)
	{
		fprintf(stderr, "plcopy:  will not overwrite %s\n",outmod);
		exit (1);
	}
	outfp = fopen(outmod,"w");
	if (!outfp)
	{
		fprintf(stderr, "plcopy:  unable to create file %s\n",outmod);
		exit (1);
	}

	/*  Read the first line and convert it into an *IDENT line  */
	while (fgets(buffer,BUFSIZ,infp) != NULL && strncmp(buffer,"*c",2) == 0)
	{
		strcpy(buffer2,"*/*");
		tptr = &buffer[2];
		strcat(buffer2,tptr);
		if (fputs(buffer2,outfp) == NULL)
		{
			fprintf(stderr, "plcopy:  unable to write to %s\n",outmod);
			(void) fclose(outfp);
			(void) unlink(outmod);
			exit (1);
		}
	}

	if (strncmp(buffer,"*m ",3) != 0 && strncmp(buffer,"*m\t",3) != 0)
	{
		fprintf(stderr, "plcopy:  bad format of mod %s\n",inmod);
		(void) fclose(outfp);
		(void) unlink(outmod);
		exit (1);
	}

	trim(buffer);
	strcpy(buffer2,"*IDENT ");
	strcat(buffer2,outmodid);


	strcat(buffer2,",DC=.\n");
	if (fputs(buffer2,outfp) == NULL)
	{
		fprintf(stderr, "plcopy:  unable to write to %s\n",outmod);
		(void) fclose(outfp);
		(void) unlink(outmod);
		exit (1);
	}
	strcpy(buffer2,"*/*     - Converted from mod ");
	strcat(buffer2,inmodid);
	strcat(buffer2,"\n");
	if (fputs(buffer2,outfp) == NULL)
	{
		fprintf(stderr, "plcopy:  unable to write to %s\n",outmod);
		(void) fclose(outfp);
		(void) unlink(outmod);
		exit (1);
	}
	deck = 0;
	basedeck = 0;
	lastcomment = 1;

	while (fgets(buffer,BUFSIZ,infp) != NULL)
	{
		if (strncmp(buffer,"*c",2) == 0)
		{
			/*  This is a comment line  */
			tptr = &buffer[2];
			strcpy(buffer2,"*/*");
			strcat(buffer2,tptr);
			lastcomment = 1;
			if (fputs(buffer2,outfp) == NULL)
			{
				fprintf(stderr, "plcopy:  unable to write to %s\n",
					outmod);
				(void) fclose(outfp);
				(void) unlink(outmod);
				exit (1);
			}
		}
		else if (strncmp(buffer,"*f ",3) == 0)
		{
			/*  This is a *f line, find the name of the deck  */
			lastcomment = 1;
			trim(buffer);
			strcpy(buffer2,"*DC ");
			tptr = &buffer[3];
			while (tptr[0] == ' ' || tptr[0] == '\t') tptr++;
			if (qstr)
			{
				/*  Make sure this portion begins with
				    the qstr  */
				if (strncmp(tptr,qstr,qlen) != 0)
				{
					fprintf(stderr, "plcopy:  Error in *f line\n");
					fprintf(stderr, "%s\n",buffer);
					(void) fclose(outfp);
					(void) unlink(outmod);
					exit (1);
				}
				tptr = tptr+qlen;
				if (strlen(tptr) == 0)
				{
					fprintf(stderr, "plcopy:  Error in *f line\n");
					fprintf(stderr, "%s\n",buffer);
					(void) fclose(outfp);
					(void) unlink(outmod);
					exit (1);
				}
			}
			strcat(buffer2,tptr);
			strcat(buffer2,"\n");

			/*  Save the deck name and the base deck name  */
			if (deck)
			{
				deck = (char *)realloc(deck,strlen(tptr)+1);
				basedeck = (char *)realloc(basedeck,strlen(tptr)+1);
			}
			else
			{
				deck = (char *)malloc(strlen(tptr)+1);
				basedeck = (char *)malloc(strlen(tptr)+1);
			}
			strcpy(deck,tptr);

			/*   Find the base name  */
			tptr = strrchr(deck,'/');
			if (tptr)
				tptr++;
			else
				tptr = deck;

			strcpy(basedeck,tptr);
			tptr = strrchr(basedeck,'.');
			if (tptr) tptr[0] = '\0';
			if (fputs(buffer2,outfp) == NULL)
			{
				fprintf(stderr, "plcopy:  unable to write to %s\n",
					outmod);
				(void) fclose(outfp);
				(void) unlink(outmod);
				exit (1);
			}
		}
		else if (strncmp(buffer,"*n ",3) == 0)
		{
			/*  This is a *n line, find the name of the deck */
			lastcomment = 0;
			trim(buffer);
			strcpy(buffer2,"*DECK ");
			tptr = &buffer[3];
			while (tptr[0] == ' ' || tptr[0] == '\t') tptr++;
			if (qstr)
			{
				/*  Make sure this portion begins with
				    the qstr  */
				if (strncmp(tptr,qstr,qlen) != 0)
				{
					fprintf(stderr, "plcopy:  Error in *n line\n");
					fprintf(stderr, "%s\n",buffer);
					(void) fclose(outfp);
					(void) unlink(outmod);
					exit (1);
				}
				tptr = tptr+qlen;
				if (strlen(tptr) == 0)
				{
					fprintf(stderr, "plcopy:  Error in *n line\n");
					fprintf(stderr, "%s\n",buffer);
					(void) fclose(outfp);
					(void) unlink(outmod);
					exit (1);
				}
			}
			strcat(buffer2,tptr);
			strcat(buffer2,",DW=*\n");
			if (fputs(buffer2,outfp) == NULL)
			{
				fprintf(stderr, "plcopy:  unable to write to %s\n",
					outmod);
				(void) fclose(outfp);
				(void) unlink(outmod);
				exit (1);
			}
		}
		else if (strncmp(buffer,"*i ",3) == 0)
		{
			/*  This is a *i line, get the identifier  */
			lastcomment = 0;
			trim(buffer);
			strcpy(buffer2,"*I ");
			if (!newusmid(buffer,&newid1,&newid2,basedeck,deck,qlen))
			{
				/*  Error getting the new id  */
				(void) fclose(outfp);
				(void) unlink(outmod);
				exit (1);
			}
			if (!newid1 || newid2)
			{
				/*  Error in the format of the directive */
				fprintf(stderr, "plcopy:  Error in format of mod\n");
				fprintf(stderr, "%s\n",buffer);
				(void) fclose(outfp);
				(void) unlink(outmod);
				exit (1);
			}
			strcat(buffer2,newid1);
			free(newid1);
			strcat(buffer2,"\n");
			if (fputs(buffer2,outfp) == NULL)
			{
				fprintf(stderr, "plcopy:  unable to write to %s\n",
					outmod);
				(void) fclose(outfp);
				(void) unlink(outmod);
				exit (1);
			}
		}
		else if (strncmp(buffer,"*b ",3) == 0)
		{
			/*  This is a *b line, get the identifier  */
			lastcomment = 0;
			trim(buffer);
			strcpy(buffer2,"*B ");
			if (!newusmid(buffer,&newid1,&newid2,basedeck,deck,qlen))
			{
				/*  Error getting the id from the line  */
				(void) fclose(outfp);
				(void) unlink(outmod);
				exit (1);
			}
			if (!newid1 || newid2)
			{
				fprintf(stderr, "plcopy:  Error in format of mod\n");
				fprintf(stderr, "%s\n",buffer);
				(void) fclose(outfp);
				(void) unlink(outmod);
				exit (1);
			}
			strcat(buffer2,newid1);
			free(newid1);
			strcat(buffer2,"\n");
			if (fputs(buffer2,outfp) == NULL)
			{
				fprintf(stderr, "plcopy:  unable to write to %s\n",
					outmod);
				(void) fclose(outfp);
				(void) unlink(outmod);
				exit (1);
			}
		}
		else if (strncmp("*d ",buffer,3) == 0)
		{
			/*  *delete directive  */
			lastcomment = 0;
			strcpy(buffer2,"*D ");
			buffer[strlen(buffer)-1] = '\0';
			if (!newusmid(buffer,&newid1,&newid2,basedeck,deck,qlen))
			{
				/*  Error getting the id from the directive line */
				(void) fclose(outfp);
				(void) unlink(outmod);
				exit (1);
			}
			if (!newid1)
			{
				fprintf(stderr, "plcopy:  Error in format of mod\n");
				fprintf(stderr, "%s\n",buffer);
				(void) fclose(outfp);
				(void) unlink(outmod);
				exit (1);
			}
			strcat(buffer2,newid1);
			free(newid1);
			if (newid2)
			{
				strcat(buffer2,",");
				strcat(buffer2,newid2);
				free(newid2);
			}
			strcat(buffer2,"\n");
			if (fputs(buffer2,outfp) == NULL)
			{
				fprintf(stderr, "plcopy:  unable to write to %s\n",
					outmod);
				(void) fclose(outfp);
				(void) unlink(outmod);
				exit (1);
			}
		}
		else if (strncmp(buffer,"*m ",3) == 0)
		{
			/*  More than one *m directive not allowed */
			fprintf(stderr, "plcopy:  Error in mod %s, multiple *m lines\n",
				inmod);
			(void) fclose(outfp);
			(void) unlink(outmod);
			exit (1);
		}
		else
		{
			/*  Not a directive.  If the last directive was a comment, then
			    blank lines are skipped, but textual lines are an error  */
			strcpy(buffer2,buffer);
			if (lastcomment)
			{
				trim(buffer);
				if (strlen(buffer) != 0)
				{
					fprintf(stderr, "plcopy:  Error in mod %s, bad directive at:\n",
						inmod);
					fprintf(stderr, "%s\n",buffer2);
					(void) fclose(outfp);
					(void) unlink(outmod);
					exit (1);
				}
			}
			if (strlen(buffer) != 0)
			{
				if (fputs(buffer2,outfp) == NULL)
				{
					fprintf(stderr, "plcopy:  unable to write to %s\n",
						outmod);
					(void) fclose(outfp);
					(void) unlink(outmod);
					exit (1);
				}
			}
		}
	}
}
