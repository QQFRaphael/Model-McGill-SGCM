	static char USMID[] = "@(#)plcopy/isscm.c	81.0	09/26/93 19:03:21";
/*	COPYRIGHT CRAY RESEARCH, INC.
 *	UNPUBLISHED -- ALL RIGHTS RESERVED UNDER
 *	THE COPYRIGHT LAWS OF THE UNITED STATES.
 */
#include <stdio.h>
int
isscm(scmpl)
char *scmpl;

{

	extern char buffer[];
	char *temp, *tptr;
	extern int dir();
	extern char *strchr();
	FILE *fp;

	if (!dir(scmpl))
	{
		fprintf(stderr, "plcopy:  %s is not a directory\n",scmpl);
		return(0);
	}

	temp = (char *)malloc(strlen(scmpl)+1+5);
	strcpy(temp,scmpl);
	strcat(temp,"/.SCM");
	if (!dir(scmpl))
	{
		fprintf(stderr, "plcopy:  %s is not a directory\n",temp);
		return(0);
	}

	/*
		Now, make sure that the .history file exists, and has no
		mods associated with it.  If it does, they need to do a
		permapply of those files that have mods before converting
		to nupdate format.
	*/


	temp = (char *)realloc(temp,strlen(temp)+15);
	strcat(temp,"/.history");

	fp = fopen(temp,"r");
	if (!fp)
	{
		fprintf(stderr, "plcopy:  %s does not exist\n",temp);
		return(0);
	}

	while (fgets(buffer,500,fp))
	{
		tptr = strchr(buffer,':');
		if (!tptr)
		{
			fprintf(stderr, "plcopy:  Invalid file information in %s\n",
				temp);
			return(0);
		}
		/*  If the next character is not a new line, then this file
		    has a mod associated with it.  */
		tptr++;
		if (tptr[0] != '\n')
		{
			/*  figure out what file it is  */
			tptr = strchr(buffer,'\t');
			if (!tptr)
			{
				strcpy(buffer,"?????");
			}
			else
			{
				tptr[0] = '\0';
			}
			fprintf(stderr, "plcopy:  %s has mods associated with it\n",buffer);
			return(0);
		}
	}
	(void) fclose(fp);

	/*  Finally, make sure that the .filelist file exists  */
	strcpy(temp,scmpl);
	strcat(temp,"/.SCM/.filelist");
	fp = fopen(temp,"r");

	if (!fp)
	{
		fprintf(stderr, "plcopy:  %s does not exist\n",temp);
		return(0);
	}
	(void) fclose(fp);
	free(temp);
	return(1);
}
