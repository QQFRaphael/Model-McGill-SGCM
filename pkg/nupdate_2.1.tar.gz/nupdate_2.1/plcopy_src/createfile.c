	static char USMID[] = "@(#)plcopy/createfile.c	81.0	09/26/93 19:03:21";
/*	COPYRIGHT CRAY RESEARCH, INC.
 *	UNPUBLISHED -- ALL RIGHTS RESERVED UNDER
 *	THE COPYRIGHT LAWS OF THE UNITED STATES.
 */
#include <stdio.h>

FILE *
createfile(name)
char *name;

{
	char *dirname;
	char *ptr;

	extern char *strchr();
	extern int dir();

	/*
		This routine recursively creates the file passed in, making
		sure all subdirectories exist
	*/

	dirname = name;
	ptr = strchr(dirname,'/');
	while (ptr)
	{
		ptr[0] = '\0';
		if (!dir(name))
		{
			if (mkdir(name,0755) != 0)
			{
				ptr[0] = '/';
				return(0);
			}
		}
		ptr[0] = '/';
		dirname = ptr+1;
		ptr = strchr(dirname,'/');
	}
	return(fopen(name,"w+"));
}
