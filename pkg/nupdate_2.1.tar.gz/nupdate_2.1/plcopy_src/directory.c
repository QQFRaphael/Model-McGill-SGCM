	static char USMID[] = "@(#)plcopy/directory.c	81.0	09/26/93 19:03:21";
/*	COPYRIGHT CRAY RESEARCH, INC.
 *	UNPUBLISHED -- ALL RIGHTS RESERVED UNDER
 *	THE COPYRIGHT LAWS OF THE UNITED STATES.
 */
#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include "pltabs.h"

directory(inpl, outpl)
char *inpl, *outpl;

{

	/*
		This routine converts a new format UNICOS PL in
		directory format to a new format COS PL.
	*/

	char name[1000];
	char *namespc, *plinfoname, *tidentname, *tptr;

	int bufptr, enddeck, lastcw, lasteof, lastrcw, i, namesplen;
	int numdecks=0, nummods=0, nw, nw2, oldpl, tidcnt, tidptr;
	long numbcws;

	struct
	{
		union
		{
			struct
			{
				char cc;
				char mc;
				unsigned pmc:1;
				unsigned un1:1;
				unsigned idcnt:14;
				unsigned idpos:32;
			}flags;
			char stuff[8];
		}word1;
		char date[8];
		union
		{
			struct
			{
				unsigned idpart1:32;
				unsigned idpart2:32;
			}flags;
			char stuff[8];
		}word3;
		union
		{
			struct
			{
				unsigned un2:32;
				unsigned un3:12;
				unsigned dw:10;
				unsigned pldw:10;
			}flags;
			char stuff[8];
		}word4;
		char unused[8];
		char signature[8];
	}plinfo;

	struct newidt tempid, *tident, *modids;

	union
	{
		struct
		{
			unsigned part1:32;
			unsigned part2:32;
		}flags;
		char stuff[8];
	}one_word;

	union cardheader hdr;
	union
	{
		struct cw control;
		char stuff[8];
	}buffer[512];

	

	FILE *infp, *outfp;

	extern int validpl();




	/*  Open up the plinfo file and read in the table  */
	plinfoname = (char *)malloc(strlen(inpl)+9);
	strcpy(plinfoname,inpl);
	strcat(plinfoname,"/.PLINFO");
	infp = fopen(plinfoname,"r b");
	if (!infp)
	{
		fprintf(stderr,"plcopy:  Unable to open file %s\n",plinfoname);
		exit (1);
	}

	if (fread((char *)&plinfo,48,1,infp) != 1)
	{
		fprintf(stderr, "plcopy:  unable to read from file %s\n",plinfoname);
		exit (1);
	}
	(void) fclose(infp);

	/*  validate plinfo table  */
	oldpl = validinfo(&plinfo);
	if (oldpl)
	{
		fprintf(stderr, "plcopy:  Invalid PL, old check character\n");
		exit (1);
	}

	/*  Read in the TIDENT and the namespace  */
	tidentname = (char *)malloc(strlen(inpl)+9);
	strcpy(tidentname,inpl);
	strcat(tidentname,"/.TIDENT");
	infp = fopen(tidentname,"r b");
	if (!infp)
	{
		fprintf(stderr, "plcopy:  Unable to open file %s\n",tidentname);
		exit (1);
	}

	tidcnt = plinfo.word1.flags.idcnt;

	tident = (struct newidt *)malloc(tidcnt*sizeof(struct newidt));
	modids = (struct newidt *)malloc(tidcnt*sizeof(struct newidt));

	while (tidcnt > 0)
	{
		if (fread((char *)&tempid, sizeof (struct newidt),1,infp) != 1)
		{
			fprintf(stderr, "plcopy:  unable to read from file %s\n",tidentname);
			exit (1);
		}
		tempid.part3.flags.timestamp = 0;
		if (tempid.part2.flags.type != 0)
		{
			/*  This is a deck, copy into tident[numdecks]  */
			tident[numdecks] = tempid;
			numdecks++;
		}
		else
		{
			modids[nummods] = tempid;
			nummods++;
		}
		tidcnt--;
	}

	/*  Read in the name space  */
	if (fread(one_word.stuff,8,1,infp) != 1)
	{
		fprintf(stderr, "plcopy:  unable to read from %s\n",inpl);
		exit (1);
	}
	namesplen = one_word.flags.part2;
	namespc = (char *)malloc(namesplen*8+1);
	if (fread((char *)namespc,8,namesplen,infp) != namesplen)
	{
		fprintf(stderr, "plcopy:  unable to read namespace from %s\n",tidentname);
		exit (1);
	}
	if (fread((char *)&one_word,8,1,infp) == 1)
	{
		fprintf(stderr, "plcopy:  not at end of file in %s\n",tidentname);
		exit (1);
	}
	(void) fclose(infp);

	/*  Go through and read in every record, building control words as we go  */

	outfp = fopen(outpl,"w b");
	if (!outfp)
	{
		fprintf(stderr, "plcopy:  Cannot open %s\n",outpl);
		exit (1);
	}

	lastcw = tidptr = 0;

	/*  Build a BCW word  */
	buildbcw(buffer,0);
	lastcw=0;
	numbcws = lasteof = lastrcw = bufptr = 1;
	
	while (tidptr<numdecks)
	{
		tptr = namespc+(tident[tidptr].part1.flags.offset-1)*8;
		strcpy(name,inpl);
		strcat(name,"/");
		strncat(name,tptr,tident[tidptr].part1.flags.namelen);
		strcat(name,".u");
		infp = fopen(name,"r b");
		if (!infp)
		{
			fprintf(stderr, "plcopy:  Cannot open %s\n",name);
			unlink(outpl);
			exit (1);
		}
		tident[tidptr].part2.flags.pos = ftell(outfp)/8+bufptr-numbcws;

		enddeck = 0;
		while (!enddeck)
		{
			/*  Read in the header  */
			if (fread(hdr.stuff,8,1,infp) != 1)
			{
				fprintf(stderr, "plcopy:  Cannot read %s\n",name);
				unlink(outpl);
				exit (1);
			}

			if (hdr.flags.flags == 0 && hdr.flags.charcnt == 0 &&
				hdr.flags.seq1 == 0 && hdr.flags.seq2 == 0 &&
				hdr.flags.hdc == 0 && hdr.flags.id == 0)
			{
				enddeck = 1;
			}
			else
			{
				/*  Determine the number of words to read  */
				for (i=0;i<8;i++)
					buffer[bufptr].stuff[i] = hdr.stuff[i];
				bufptr++;
				nw = (hdr.flags.charcnt+7)/8 + (hdr.flags.hdc+2)/4;

				if (bufptr+nw <= 512)
				{
					/*  Read the entire record into buffer */
					if (fread(&buffer[bufptr],8,nw,infp) != nw)
					{
						fprintf(stderr, "plcopy:  Cannot read from %s\n",
							name);
						unlink(outpl);
						exit (1);
					}
					bufptr = bufptr+nw;
					/*  Determine whether the RCW will fit */
					if (bufptr==512)
					{
						write_buff(buffer,lastcw,outfp,outpl);
						buildbcw(buffer,numbcws);
						bufptr = 1;
						lastcw = 0;
						numbcws++;
					}
					/*  Build an RCW  */
					buildcw(buffer,bufptr,8,numbcws,lasteof,lastrcw,lastcw);
					lastcw = bufptr;
					bufptr++;
					lastrcw = numbcws;
				}
				else
				{
					/*  Read in part of a record, write out the buffer, and
					read in the rest of the record  */
					nw2 = 512-bufptr;
					if (fread(&buffer[bufptr],8,nw2,infp) != nw2)
					{
						fprintf(stderr, "plcopy:  Cannot read from %s\n",
							name);
						unlink(outpl);
						exit (1);
					}
					write_buff(buffer,lastcw,outfp,outpl);
					buildbcw(buffer,numbcws);
					bufptr = 1;
					lastcw = 0;
					numbcws++;
					nw = nw-nw2;
					if (fread(&buffer[bufptr],8,nw,infp) != nw)
					{
						fprintf(stderr, "plcopy:  Cannot read from %s\n",
							name);
						unlink(outpl);
						exit (1);
					}
					bufptr = bufptr+nw;
					/*  Build an RCW  */
					buildcw(buffer,bufptr,8,numbcws,lasteof,lastrcw,lastcw);
					lastcw = bufptr;
					bufptr++;
					lastrcw = numbcws;
				}
			}
			if (bufptr==512)
			{
				/*  This word needs to be written out  */
				write_buff(buffer,lastcw,outfp,outpl);
				buildbcw(buffer,numbcws);
				bufptr = 1;
				lastcw = 0;
				numbcws++;
			}
		}
		/*  We are at the end of the deck, create a EOF  */
		buildcw(buffer,bufptr,14,numbcws,lasteof,lastrcw,lastcw);
		lastcw = bufptr;
		bufptr++;
		lasteof = numbcws;
		if (bufptr==512)
		{
			/*  This word needs to be written out  */
			write_buff(buffer,lastcw,outfp,outpl);
			buildbcw(buffer,numbcws);
			bufptr = 1;
			lastcw = 0;
			numbcws++;
		}
		(void) fclose(infp);
		tidptr++;
	}
	/*  At the end of all decks, copy the tident into the buffer */
	plinfo.word1.flags.idpos = ftell(outfp)/8+bufptr-numbcws;
	for (tidptr=0;tidptr<numdecks;tidptr++)
	{
		if (bufptr==512)
		{
			/*  This word needs to be written out  */
			write_buff(buffer,lastcw,outfp,outpl);
			buildbcw(buffer,numbcws);
			bufptr = 1;
			lastcw = 0;
			numbcws++;
		}
		/*  There are three scenarios  */
		if (bufptr<510)
		{
			/*  copy all three words for this entry  */
			for (i=0;i<8;i++)
				buffer[bufptr].stuff[i] = tident[tidptr].part1.stuff[i];
			bufptr++;
			for (i=0;i<8;i++)
				buffer[bufptr].stuff[i] = tident[tidptr].part2.stuff[i];
			bufptr++;
			for (i=0;i<8;i++)
				buffer[bufptr].stuff[i] = tident[tidptr].part3.stuff[i];
			bufptr++;
		}
		else if (bufptr==510)
		{
			/*  copy two words for this entry, start a new block, and copy the last  */
			for (i=0;i<8;i++)
				buffer[bufptr].stuff[i] = tident[tidptr].part1.stuff[i];
			bufptr++;
			for (i=0;i<8;i++)
				buffer[bufptr].stuff[i] = tident[tidptr].part2.stuff[i];
			write_buff(buffer,lastcw,outfp,outpl);
			buildbcw(buffer,numbcws);
			bufptr = 1;
			lastcw = 0;
			numbcws++;
			for (i=0;i<8;i++)
				buffer[bufptr].stuff[i] = tident[tidptr].part3.stuff[i];
			bufptr++;
		}
		else
		{
			/*  copy 1 word for this entry, start a new block, and copy the last  */
			for (i=0;i<8;i++)
				buffer[bufptr].stuff[i] = tident[tidptr].part1.stuff[i];
			write_buff(buffer,lastcw,outfp,outpl);
			buildbcw(buffer,numbcws);
			bufptr = 1;
			lastcw = 0;
			numbcws++;
			for (i=0;i<8;i++)
				buffer[bufptr].stuff[i] = tident[tidptr].part2.stuff[i];
			bufptr++;
			for (i=0;i<8;i++)
				buffer[bufptr].stuff[i] = tident[tidptr].part3.stuff[i];
			bufptr++;
		}
	}
	for (tidptr=0;tidptr<nummods;tidptr++)
	{
		if (bufptr==512)
		{
			/*  This word needs to be written out  */
			write_buff(buffer,lastcw,outfp,outpl);
			buildbcw(buffer,numbcws);
			bufptr = 1;
			lastcw = 0;
			numbcws++;
		}
		/*  There are three scenarios  */
		if (bufptr<510)
		{
			/*  copy all three words for this entry  */
			for (i=0;i<8;i++)
				buffer[bufptr].stuff[i] = modids[tidptr].part1.stuff[i];
			bufptr++;
			for (i=0;i<8;i++)
				buffer[bufptr].stuff[i] = modids[tidptr].part2.stuff[i];
			bufptr++;
			for (i=0;i<8;i++)
				buffer[bufptr].stuff[i] = modids[tidptr].part3.stuff[i];
			bufptr++;
		}
		else if (bufptr==510)
		{
			/*  copy two words for this entry, start a new block, and copy the last  */
			for (i=0;i<8;i++)
				buffer[bufptr].stuff[i] = modids[tidptr].part1.stuff[i];
			bufptr++;
			for (i=0;i<8;i++)
				buffer[bufptr].stuff[i] = modids[tidptr].part2.stuff[i];
			write_buff(buffer,lastcw,outfp,outpl);
			buildbcw(buffer,numbcws);
			bufptr = 1;
			lastcw = 0;
			numbcws++;
			for (i=0;i<8;i++)
				buffer[bufptr].stuff[i] = modids[tidptr].part3.stuff[i];
			bufptr++;
		}
		else
		{
			/*  copy 1 word for this entry, start a new block, and copy the last  */
			for (i=0;i<8;i++)
				buffer[bufptr].stuff[i] = modids[tidptr].part1.stuff[i];
			write_buff(buffer,lastcw,outfp,outpl);
			buildbcw(buffer,numbcws);
			bufptr = 1;
			lastcw = 0;
			numbcws++;
			for (i=0;i<8;i++)
				buffer[bufptr].stuff[i] = modids[tidptr].part2.stuff[i];
			bufptr++;
			for (i=0;i<8;i++)
				buffer[bufptr].stuff[i] = modids[tidptr].part3.stuff[i];
			bufptr++;
		}
	}

	/*  Now, copy the name space into the buffer, separated by an RCW  */
	if (bufptr==512)
	{
		write_buff(buffer,lastcw,outfp,outpl);
		buildbcw(buffer,numbcws);
		bufptr = 1;
		lastcw = 0;
		numbcws++;
	}

	/*  Build an RCW  */
	buildcw(buffer,bufptr,8,numbcws,lasteof,lastrcw,lastcw);
	lastcw = bufptr;
	bufptr++;
	lastrcw=numbcws;
	if (bufptr==512)
	{
		write_buff(buffer,lastcw,outfp,outpl);
		buildbcw(buffer,numbcws);
		bufptr = 1;
		lastcw = 0;
		numbcws++;
	}
	one_word.flags.part1 = ftell(outfp)/8+bufptr-numbcws;
	one_word.flags.part2 = namesplen;
	for (i=0;i<8;i++)
		buffer[bufptr].stuff[i] = one_word.stuff[i];
	bufptr++;
	if (bufptr==512)
	{
		write_buff(buffer,lastcw,outfp,outpl);
		buildbcw(buffer,numbcws);
		bufptr = 1;
		lastcw = 0;
		numbcws++;
	}
	tptr = namespc;
	for (tidptr=0;tidptr<namesplen;tidptr++)
	{
		for (i=0;i<8;i++)
			buffer[bufptr].stuff[i] = tptr[i];
		bufptr++;
		tptr = tptr+8;
		if (bufptr==512)
		{
			write_buff(buffer,lastcw,outfp,outpl);
			buildbcw(buffer,numbcws);
			bufptr = 1;
			lastcw = 0;
			numbcws++;
		}
	}

	/*  Now, lastly, create an EOR, EOF sequence, and copy in the plinfo table  */
	buildcw(buffer,bufptr,8,numbcws,lasteof,lastrcw,lastcw);
	lastcw = bufptr;
	bufptr++;
	lastrcw=numbcws;
	if (bufptr==512)
	{
		write_buff(buffer,lastcw,outfp,outpl);
		buildbcw(buffer,numbcws);
		bufptr = 1;
		lastcw = 0;
		numbcws++;
	}
	buildcw(buffer,bufptr,14,numbcws,lasteof,lastrcw,lastcw);
	lastcw = bufptr;
	bufptr++;
	lasteof = numbcws;
	if (bufptr==512)
	{
		write_buff(buffer,lastcw,outfp,outpl);
		buildbcw(buffer,numbcws);
		bufptr = 1;
		lastcw = 0;
		numbcws++;
	}
	/*  Now, copy in the plinfo words  */

	for (i=0;i<8;i++)
		buffer[bufptr].stuff[i] = plinfo.word1.stuff[i];
	bufptr++;
	if (bufptr==512)
	{
		write_buff(buffer,lastcw,outfp,outpl);
		buildbcw(buffer,numbcws);
		bufptr = 1;
		lastcw = 0;
		numbcws++;
	}

	strncpy(buffer[bufptr].stuff,plinfo.date,8);
	bufptr++;
	if (bufptr==512)
	{
		write_buff(buffer,lastcw,outfp,outpl);
		buildbcw(buffer,numbcws);
		bufptr = 1;
		lastcw = 0;
		numbcws++;
	}

	for (i=0;i<8;i++)
		buffer[bufptr].stuff[i] = plinfo.word3.stuff[i];
	bufptr++;
	if (bufptr==512)
	{
		write_buff(buffer,lastcw,outfp,outpl);
		buildbcw(buffer,numbcws);
		bufptr = 1;
		lastcw = 0;
		numbcws++;
	}

	for (i=0;i<8;i++)
		buffer[bufptr].stuff[i] = plinfo.word4.stuff[i];
	bufptr++;
	if (bufptr==512)
	{
		write_buff(buffer,lastcw,outfp,outpl);
		buildbcw(buffer,numbcws);
		bufptr = 1;
		lastcw = 0;
		numbcws++;
	}

	for (i=0;i<8;i++)
		buffer[bufptr].stuff[i] = plinfo.unused[i];
	bufptr++;
	if (bufptr==512)
	{
		write_buff(buffer,lastcw,outfp,outpl);
		buildbcw(buffer,numbcws);
		bufptr = 1;
		lastcw = 0;
		numbcws++;
	}

	for (i=0;i<8;i++)
		buffer[bufptr].stuff[i] = plinfo.signature[i];
	bufptr++;
	if (bufptr==512)
	{
		write_buff(buffer,lastcw,outfp,outpl);
		buildbcw(buffer,numbcws);
		bufptr = 1;
		lastcw = 0;
		numbcws++;
	}

	/*  Create an EOR, EOF and EOD  */
	buildcw(buffer,bufptr,8,numbcws,lasteof,lastrcw,lastcw);
	lastcw = bufptr;
	lastrcw=numbcws;
	bufptr++;
	if (bufptr==512)
	{
		write_buff(buffer,lastcw,outfp,outpl);
		buildbcw(buffer,numbcws);
		bufptr = 1;
		lastcw = 0;
		numbcws++;
	}

	buildcw(buffer,bufptr,14,numbcws,lasteof,lastrcw,lastcw);
	lastcw = bufptr;
	bufptr++;
	lasteof = numbcws;
	if (bufptr==512)
	{
		write_buff(buffer,lastcw,outfp,outpl);
		buildbcw(buffer,numbcws);
		bufptr = 1;
		lastcw = 0;
		numbcws++;
	}

	buildcw(buffer,bufptr,15,numbcws,lasteof,lastrcw,lastcw);
	buffer[bufptr].control.fwi = 0;

	if (fwrite(buffer,8,bufptr+1,outfp) != bufptr+1)
	{
		fprintf(stderr, "plcopy:  Cannot write to %s\n",outpl);
		unlink(outpl);
		exit (1);
	}
	(void) fclose(outfp);
	return;
}
