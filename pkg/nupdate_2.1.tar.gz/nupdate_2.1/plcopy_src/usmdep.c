	static char USMID[] = "@(#)plcopy/usmdep.c	81.0	09/26/93 19:03:21";
/*	COPYRIGHT CRAY RESEARCH, INC.
 *	UNPUBLISHED -- ALL RIGHTS RESERVED UNDER
 *	THE COPYRIGHT LAWS OF THE UNITED STATES.
 */
#include <stdio.h>
#include "modinfo.h"

char *
usmdep(id,seq,deck)
char *id, *seq, *deck;

{
	extern char *direct;
	extern struct list *modlist, *tail;

	char appchar, *modid, *modname, *res, *thisdeck, *tptr;
	char buffer[BUFSIZ], newseq[10];

	int appended, i, idfound, lastcomment, offset, skip;

	struct list *p;

	FILE *fp;

	extern char *strchr(), *strrchr();



	res = 0;
	thisdeck = 0;
	lastcomment = 1;

	modname = (char *)malloc(strlen(direct)+1+strlen(id)+1);
	strcpy(modname,direct);
	strcat(modname,"/");
	strcat(modname,id);

	/*  Determine if the mod is in the specified directory  */
	fp = fopen(modname,"r");
	if (!fp)
	{
		free(modname);
		return(res);
	}

	/*  Check the mod list to see if this mod was already processed  */
	idfound = 0;

	if (modlist)
	{
		/*  Search through the mod list for this id */
		p = modlist;
		while (p)
		{
			if (strcmp(p->id,id) == 0)
			{
				/*  this is is found, check if the decks match  */
				idfound = 1;
				if (strcmp(deck,p->deck) == 0)
				{
					/*  this is an actual match  */
					res = (char *)malloc(strlen(p->id2)+strlen(seq)+2);
					strcpy(res,p->id2);
					strcat(res,".");
					i = atol(seq);
					i = i-p->offset;
					sprintf(newseq,"%d",i);
					strcat(res,newseq);
					(void) fclose(fp);
					free(modname);
					return(res);
				}
			}
			p = p->next;
		}
		if (idfound)
		{
			/*  found id where it should be, but not matching deck  */
			fprintf(stderr, "plcopy:  Error, id %s not found in mod %s\n",
				modname);
			exit (1);
		}
	}

	/*  If it gets here, the file needs to be processed */
	modid = (char *)malloc(strlen(id)+2);
	strcpy(modid,id);
	appchar = 'a';
	appended = 0;
	i = strlen(modid);
	modid[i] = appchar;
	modid[i+1] = '\0';

	if (!modlist)
	{
		modlist = (struct list *)malloc(sizeof(struct list));
		modlist->next = 0;
		tail = modlist;
		p = modlist;
	}
	else
	{
		tail->next = (struct list *)malloc(sizeof(struct list));
		tail = tail->next;
		tail->next = 0;
		p = tail;
	}
	p->id = (char *)malloc(strlen(id)+1);
	strcpy(p->id,id);
	p->id2 = (char *)malloc(strlen(modid)+1);
	strcpy(p->id2,modid);
	p->offset = 0;
	offset = 0;


	/*  Determine what deck is being changed by this mod id by reading the *IDENT,
	    or up to the first DC or DECK directive */
	if (fgets(buffer,BUFSIZ,fp) == NULL)
	{
		fprintf(stderr, "plcopy:  empty mod in %s\n",modname);
		exit (1);
	}
	trim(buffer);
	if (strncmp(buffer,"*IDENT ",7) != 0)
	{
		fprintf(stderr, "plcopy:  mod %s is not a usm mod\n",modname);
		exit (1);
	}

	/*  Find the DC and determine if it is an ID or a .  */
	tptr = strchr(buffer,',');
	if (!tptr)
	{
		fprintf(stderr, "plcopy:  mod %s is not a usm mod\n",modname);
		exit (1);
	}
	thisdeck = tptr+1;
	tptr = strchr(thisdeck,'=');
	if (!tptr)
	{
		fprintf(stderr, "plcopy:  mod %s is not a usm mod\n",modname);
		exit (1);
	}
	tptr[0] = '\0';
	tptr++;
	if (strcmp(thisdeck,"DC") != 0)
	{
		fprintf(stderr, "plcopy:  mod %s is not a usm mod\n",modname);
		exit (1);
	}
	thisdeck = tptr;
	tptr = strchr(thisdeck,',');
	if (tptr)tptr[0] = '\0';
	tptr = thisdeck;

	lastcomment = 1;
	if (strcmp(tptr,".") != 0)
	{
		/*  this is a deck name  */
		thisdeck = (char *)malloc(strlen(tptr)+1);
		strcpy(thisdeck,tptr);
		p->deck = thisdeck;
	}
	else
	{
		/*  Read up to the first DECK or DC directive */
		while (fgets(buffer,BUFSIZ,fp) != NULL &&
			strncmp(buffer,"*DC ",4) != 0 && strncmp(buffer,"*DECK ",6) != 0
			&& strncmp(buffer,"*COMDECK ",9) != 0);

		if (strncmp(buffer,"*COMDECK ",9) == 0)
		{
			fprintf(stderr, "plcopy:  mod %s has a comdeck in it\n",modname);
			exit (1);
		}
		trim(buffer);
		if (strncmp(buffer,"*DECK ",6) == 0)
		{
			skip = 1;
			lastcomment = 0;
			tptr = &buffer[6];
		}
		else
		{
			skip = 0;
			tptr = &buffer[4];
		}

		/*  Determine what this deck is */
		while (tptr[0] == ' ')tptr++;
		thisdeck = (char *)malloc(strlen(tptr)+1);
		strcpy(thisdeck,tptr);
		p->deck = thisdeck;
	}
	if (strcmp(thisdeck,deck) == 0)
	{
		/*  This is the modid being searched for */
		res = (char *)malloc(strlen(p->id2)+strlen(seq)+2);
		strcpy(res,p->id2);
		strcat(res,".");
		i = atol(seq);
		i = i-p->offset;
		sprintf(newseq,"%d",i);
		strcat(res,newseq);
	}

	/*  Read in all ids from the mod, skiping comment lines  */
	while (fgets(buffer,BUFSIZ,fp) != NULL)
	{
		if (strncmp(buffer,"*DC ",4) == 0)
		{
			/*  New *IDENT directive, increase the app character and
			    add an entry to modlist  */

			/*  Determine what this deck is */
			trim(buffer);
			tptr = &buffer[4];
			while (tptr[0] == ' ')tptr++;
			thisdeck = (char *)malloc(strlen(tptr)+1);
			strcpy(thisdeck,tptr);

			if (appchar == 'z')
			{
				if (!appended)
				{
					/*  Reset modid to a and add one character */
					modid[strlen(modid)-1] = 'a';
					appchar = 'a';
					modid = (char *)realloc(modid,strlen(modid)+2);
					modid[strlen(modid)+1] = '\0';
					modid[strlen(modid)] = appchar;
					appended = 1;
				}
				else
				{
					/*  Increase the value of the previous character  */
					appchar = modid[strlen(modid)-2];
					if (appchar == 'z')
					{
						fprintf(stderr, "plcopy:  Error, mod name overflow in %s\n",
							modname);
							exit (1);
					}
					appchar++;
					modid[strlen(modid)-2] = appchar;
					appchar = 'a';
					modid[strlen(modid)-1] = appchar;
				}
			}
			else
			{
				appchar++;
				modid[strlen(modid)-1] = appchar;
			}
			tail->next = (struct list *)malloc(sizeof(struct list));
			tail = tail->next;
			tail->next = 0;
			p = tail;
			p->offset = offset;
			p->id = (char *)malloc(strlen(id)+1);
			strcpy(p->id,id);
			p->id2 = (char *)malloc(strlen(modid)+1);
			strcpy(p->id2,modid);
			p->deck = thisdeck;
			if (strcmp(thisdeck,deck)==0)
			{
				/* this is the modid being searched for */
				res = (char *)malloc(strlen(p->id2)+strlen(seq)+2);
				strcpy(res,p->id2);
				strcat(res,".");
				i = atol(seq);
				i = i-p->offset;
				sprintf(newseq,"%d",i);
				strcat(res,newseq);
			}
			skip = 0;
			lastcomment = 1;
		}
		else if (strncmp(buffer,"*DECK ",6) == 0)
		{
			/*
				*DECK directive, increase the app character
				but don't add an entry to modlist
			*/
			if (appchar == 'z')
			{
				if (!appended)
				{
					/*  Reset modid to a, and add one character */
					modid[strlen(modid)-1] = 'a';
					appchar = 'a';
					modid = (char *)realloc(modid,strlen(modid)+2);
					modid[strlen(modid)+1] = '\0';
					modid[strlen(modid)] = appchar;
					appended = 1;
				}
				else
				{
					/*  Increase the value of the previous character  */
					appchar = modid[strlen(modid)-2];
					if (appchar == 'z')
					{
						fprintf(stderr, "plcopy:  Error, mod name overflow in %s\n",
							modname);
						exit (1);
					}
					appchar++;
					modid[strlen(modid)-2] = appchar;
					appchar = 'a';
					modid[strlen(modid)-1] = appchar;
				}
			}
			else
			{
				appchar++;
				modid[strlen(modid)-1] = appchar;
			}
			skip = 1;
			lastcomment = 0;
		}
		else if (strncmp(buffer,"*IDENT ",7) == 0)
		{
			fprintf(stderr, "plcopy:  multipl *IDENTs in mod %s\n",modname);
			exit (1);
		}
		else if (strncmp(buffer,"*COMDECK ",9) == 0)
		{
			fprintf(stderr, "plcopy:  COMDECK found in mod %s\n",modname);
			exit (1);
		}
		else if (strncmp(buffer,"*/*",3) != 0 && strncmp(buffer,"*I ",3) != 0 &&
			 strncmp(buffer,"*D ",3) != 0 && strncmp(buffer,"*B ",3) != 0)
		{
			/*  Increaes offset by 1  */
			if (lastcomment)
			{
				fprintf(stderr, "plcopy:  Bad directive in mod %s\n",modname);
				exit (1);
			}
			if (!skip) offset++;
		}
		else
		{
			lastcomment = 0;
		}
	}
	if (!res)
	{
		fprintf(stderr, "plcopy:  Error, id %s not found in mod %s\n",id,modname);
		exit (1);
	}
	(void) fclose(fp);
	free(modname);
	free(modid);
	return(res);
}
