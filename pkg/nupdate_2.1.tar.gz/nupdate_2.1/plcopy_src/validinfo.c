	static char USMID[] = "@(#)plcopy/validinfo.c	81.0	09/26/93 19:03:21";
/*	COPYRIGHT CRAY RESEARCH, INC.
 *	UNPUBLISHED -- ALL RIGHTS RESERVED UNDER
 *	THE COPYRIGHT LAWS OF THE UNITED STATES.
 */
#include <stdio.h>
struct plinfot
{
	char cc;
	char mc;
	int pmc:1;
	int un1:1;
	int idcnt:14;
	int idpos:32;
	char date[8];
	char id[8];
	int un2:32;
	int un3:12;
	int dw:10;
	int pldw:10;
	char unused[8];
	char signature[8];
};

int
validinfo(plinfo)
struct plinfot *plinfo;


{

	int ret;

	if (plinfo->cc == 'a')
	{
		fprintf(stderr, "Old pl format no longer supported\n");
		exit (1);
	}
	ret = 0;
	if (plinfo->cc == 'b' || plinfo->cc == 'c')
	{
		/*  Old pl  */
		ret = 1;
	}
	else if (plinfo->cc != 'd')
	{
		fprintf(stderr, "Invalid check character in pl\n");
		exit(1);
	}
	if (strcmp(plinfo->signature,"HIST OK "))
	{
		fprintf(stderr, "Invalid signature in pl");
		exit (1);
	}
	if (plinfo->idcnt < 0)
	{
		fprintf(stderr, "Invalid idcnt in pl\n");
		exit (1);
	}
	if (plinfo->idpos < 0)
	{
		fprintf(stderr, "Invalid idpos in pl\n");
		exit (1);
	}
	return (ret);
}
		
