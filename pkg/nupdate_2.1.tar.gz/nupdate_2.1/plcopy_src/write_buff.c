	static char USMID[] = "@(#)plcopy/write_buff.c	82.0	05/03/94 09:55:54";
/*	COPYRIGHT CRAY RESEARCH, INC.
 *	UNPUBLISHED -- ALL RIGHTS RESERVED UNDER
 *	THE COPYRIGHT LAWS OF THE UNITED STATES.
 */
#include <stdio.h>
#include "pltabs.h"


write_buff(buffer,lastcw,outfp,outpl)
union buffer_cw buffer[];
int lastcw;
FILE *outfp;
char *outpl;

{

	int i;

	buffer[lastcw].control.fwi = 511-lastcw;
	if (fwrite(buffer,8,512,outfp) != 512)
	{
		fprintf(stderr, "plcopy:  Cannot write to %s\n",outpl);
		unlink(outpl);
		exit (1);
	}
	return;
}
