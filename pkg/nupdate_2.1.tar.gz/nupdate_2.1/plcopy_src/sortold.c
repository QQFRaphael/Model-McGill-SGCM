	static char USMID[] = "@(#)plcopy/sortold.c	81.0	09/26/93 19:03:21";
/*	COPYRIGHT CRAY RESEARCH, INC.
 *	UNPUBLISHED -- ALL RIGHTS RESERVED UNDER
 *	THE COPYRIGHT LAWS OF THE UNITED STATES.
 */
#include <stdio.h>
#include "pltabs.h"

sortold(tident,tidcnt)
struct oldidt *tident;
int tidcnt;

{

	int comp_1();


	/*  this will sort it  */
	qsort((char *)tident,tidcnt,sizeof(struct oldidt),comp_1);
	return;
}

int
comp_1(el1 ,el2)
struct oldidt *el1, *el2;

{
	int retval;
	if (el1->part2.flags.pos<el2->part2.flags.pos)
	{
		retval = -1;
	}
	else
	{
		retval = 1;
	}
	return(retval);
}
