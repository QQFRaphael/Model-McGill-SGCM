	static char USMID[] = "@(#)plcopy/usmmod.c	81.0	09/26/93 19:03:21";
/*	COPYRIGHT CRAY RESEARCH, INC.
 *	UNPUBLISHED -- ALL RIGHTS RESERVED UNDER
 *	THE COPYRIGHT LAWS OF THE UNITED STATES.
 */
#include <stdio.h>

usmmod(inmod,outmod,qstr,qlen)
char *inmod, *outmod, *qstr;
int qlen;

{

	extern char buffer[];
	char buffer2[BUFSIZ];	

	char *basedeck, *deck, *id, *newid1, *newid2, *tptr;

	FILE *infp, *outfp;

	int lastcomment;

	extern char *strchr(), *strrchr();



	/*  First open the files  */
	infp = fopen(inmod,"r");
	if (!infp)
	{
		fprintf(stderr, "plcopy:  unable to open file %s\n",inmod);
		exit (1);
	}
	outfp = fopen(outmod,"r");
	if (outfp)
	{
		fprintf(stderr, "plcopy:  will not overwrite %s\n",outmod);
		exit (1);
	}
	outfp = fopen(outmod,"w+");
	if (!outfp)
	{
		fprintf(stderr, "plcopy:  unable to create file %s\n",outmod);
		exit (1);
	}

	/*  Read the first line and convert it into a *m line  */

	if (fgets(buffer,BUFSIZ,infp) == NULL)
	{
		fprintf(stderr, "plcopy:  empty file in %s\n",outmod);
		(void) fclose(outfp);
		(void) unlink(outmod);
		exit (1);
	}


	if (strncmp(buffer,"*IDENT ",7) != 0)
	{
		fprintf(stderr, "plcopy:  mod %s is not a usm mod\n",inmod);
		(void) fclose(outfp);
		(void) unlink(outmod);
		exit (1);
	}
	trim(buffer);

	strcpy(buffer2,"*m ");
	/*  get the mod id  */
	tptr = &buffer[7];
	while (tptr[0] == ' ')tptr++;
	id = tptr;
	tptr = strchr(id,',');
	if (!tptr)
	{
		fprintf(stderr, "plcopy:  mod %s is not a usm mod\n",inmod);
		(void) fclose(outfp);
		(void) unlink(outmod);
		exit (1);
	}
	tptr[0] = '\0';
	strcat(buffer2,id);
	strcat(buffer2,"\n");
	if (fputs(buffer2,outfp) == NULL)
	{
		fprintf(stderr, "plcopy:  unable to write to %s\n",outmod);
		(void) fclose(outfp);
		(void) unlink(outmod);
		exit (1);
	}

	tptr++;
	if (strncmp(tptr,"DC=",3) != 0)
	{
		fprintf(stderr, "plcopy:  mod %s is not a usm mod\n",inmod);
		(void) fclose(outfp);
		(void) unlink(outmod);
		exit (1);
	}
	tptr = strchr(tptr,'=');
	tptr++;
	deck = 0;
	if (strcmp(tptr,".")!=0)
	{
		/*  Read in the entire comment line, and then write this out  */
		id = (char *)malloc(strlen(tptr)+1);
		strcpy(id,tptr);
		while (fgets(buffer,BUFSIZ,infp) != NULL && strncmp(buffer,"*/*",3)==0)
		{
			if (strncmp(buffer,"*/*DELTA",8) == 0 ||
			    strncmp(buffer,"*/*delta",8) == 0)
			{
				tptr = &buffer[8];
				strcpy(buffer2,"*c     ");
				strcat(buffer2,tptr);
			}
			else
			{
				tptr = &buffer[3];
				strcpy(buffer2,"*c");
				strcat(buffer2,tptr);
			}
			if (fputs(buffer2,outfp) == NULL)
			{
				fprintf(stderr, "plcopy:  unable to write to %s\n",outmod);
				(void) fclose(outfp);
				(void) unlink(outmod);
				exit (1);
			}
		}
		/*  Now, create the *f line  */
		strcpy(buffer2,"*f ");
		if (qstr) strcat(buffer2,qstr);
		strcat(buffer2,id);
		strcat(buffer2,"\n");
		if (fputs(buffer2,outfp) == NULL)
		{
			fprintf(stderr, "plcopy:  unable to write to %s\n",outmod);
			(void) fclose(outfp);
			(void) unlink(outmod);
			exit (1);
		}
		deck = id;
		tptr = strrchr(deck,'/');
		if (tptr)
		{
			tptr++;
		}
		else
		{
			tptr = deck;
		}
		basedeck = (char *)malloc(strlen(tptr)+1);
		strcpy(basedeck,tptr);
		tptr = strrchr(basedeck,'.');
		if (tptr) tptr[0] = '\0';
	}
	else
	{
		(void) fgets(buffer,BUFSIZ,infp);
	}
	lastcomment = 1;
	while (!feof(infp))
	{
		if (strncmp(buffer,"*/*",3) == 0)
		{
			/*  This is a comment line  */
			if (strncmp(buffer,"*/*DELTA",8) == 0 ||
			    strncmp(buffer,"*/*delta",8) == 0)
			{
				tptr = &buffer[8];
				strcpy(buffer2,"*c     ");
				strcat(buffer2,tptr);
			}
			else
			{
				tptr = &buffer[3];
				strcpy(buffer2,"*c");
				strcat(buffer2,tptr);
			}
			lastcomment = 1;
		}
		else if (strncmp(buffer,"*DC ",3) == 0)
		{
			/*  This is a *DC line, find the name of the deck */
			strcpy(buffer2,"*f ");
			trim(buffer);
			tptr = &buffer[3];
			while (tptr[0] == ' ') tptr++;
			if (qstr)
			{
				strcat(buffer2,qstr);
			}
			if (deck)
			{
				deck = (char *)realloc(deck,strlen(tptr)+1);
				basedeck = (char *)realloc(basedeck,strlen(tptr)+1);
			}
			else
			{
				deck = (char *)malloc(strlen(tptr)+1);
				basedeck = (char *)malloc(strlen(tptr)+1);
			}
			strcpy(deck,tptr);
			tptr = strrchr(deck,'/');
			if (tptr)
				tptr++;
			else
				tptr = deck;
			strcpy(basedeck,tptr);
			tptr = strrchr(basedeck,'.');
			if (tptr) tptr[0] = '\0';
			strcat(buffer2,deck);
			strcat(buffer2,"\n");
			lastcomment = 1;
		}
		else if (strncmp(buffer,"*DECK ",6) == 0)
		{
			/*  This is a *DECK line, find the name of the deck */
			trim(buffer);
			strcpy(buffer2,"*n ");
			tptr = &buffer[6];
			while (tptr[0] == ' ')tptr++;
			if (qstr)
			{
				/* put qstr onto the pl  */
				strcat(buffer2,qstr);
			}
			id = strchr(tptr,',');
			if (id) id[0] = '\0';
			strcat(buffer2,tptr);
			strcat(buffer2,"\n");
			lastcomment = 0;
		}
		else if (strncmp(buffer,"*I ",3) == 0)
		{
			/*  This is a *I line, get the identifier */
			trim(buffer);
			strcpy(buffer2,"*i ");
			if (!newscmid(buffer,&newid1,&newid2,basedeck,deck))
			{
				(void) fclose(outfp);
				(void) unlink(outmod);
				exit (1);
			}
			if (!newid1 || newid2)
			{
				fprintf(stderr, "plcopy:  Error in format of mod\n");
				fprintf(stderr, "%s\n",buffer);
				(void) fclose(outfp);
				(void) unlink(outmod);
				exit (1);
			}
			strcat(buffer2,newid1);
			strcat(buffer2,"\n");
			lastcomment = 0;
			free(newid1);
		}
		else if (strncmp(buffer,"*B ",3)==0)
		{
			/*  This is a *B line, get the identifier */
			trim(buffer);
			strcpy(buffer2,"*b ");
			if (!newscmid(buffer,&newid1,&newid2,basedeck,deck))
			{
				(void) fclose(outfp);
				(void) unlink(outmod);
				exit (1);
			}
			if (!newid1 || newid2)
			{
				fprintf(stderr, "plcopy:  Error in format of mod\n");
				fprintf(stderr, "%s\n",buffer);
				(void) fclose(outfp);
				(void) unlink(outmod);
				exit (1);
			}
			strcat(buffer2,newid1);
			strcat(buffer2,"\n");
			lastcomment = 0;
			free(newid1);
		}
		else if (strncmp(buffer,"*D ",3) == 0)
		{
			/*  *D directive  */
			trim(buffer);
			strcpy(buffer2,"*d ");
			if (!newscmid(buffer,&newid1,&newid2,basedeck,deck))
			{
				(void) fclose(outfp);
				(void) unlink(outmod);
				exit (1);
			}
			if (!newid1)
			{
				fprintf(stderr, "plcopy:  Error in format of mod\n");
				fprintf(stderr, "%s\n",buffer);
				(void) fclose(outfp);
				(void) unlink(outmod);
				exit (1);
			}
			strcat(buffer2,newid1);
			free(newid1);
			if (newid2)
			{
				strcat(buffer2,",");
				strcat(buffer2,newid2);
				free(newid2);
			}
			lastcomment = 0;
			strcat(buffer2,"\n");
		}
		else if (strncmp(buffer,"*COMDECK ",9)==0)
		{
			fprintf(stderr, "plcopy:  Unable to add common deck to scm pl\n");
			(void) fclose(outfp);
			(void) unlink(outmod);
			exit (1);
		}
		else if (strncmp(buffer,"*IDENT ",7) == 0)
		{
			fprintf(stderr, "plcopy:  multiple *IDENTs in mod %s\n",inmod);
			(void) fclose(outfp);
			(void) unlink(outmod);
			exit (1);
		}
		else
		{
			if (lastcomment)
			{
				fprintf(stderr, "plcopy:  Bad directive in mod %s\n",inmod);
				fprintf(stderr, "%s\n",buffer);
				(void) fclose(outfp);
				(void) unlink(outmod);
				exit (1);
			}
			strcpy(buffer2,buffer);
		}
		if (strncmp(buffer2,"*PURGEDK ",9) == 0)
		{
			fprintf(stderr, "plcopy:  Unable to process purgedk directive\n");
			fprintf(stderr, "%s",buffer2);
			fprintf(stderr, "             Directive skipped\n");
		}
		else
		{
			if (fputs(buffer2,outfp) == NULL)
			{
				fprintf(stderr, "plcopy:  unable to write to %s\n",
					outmod);
				(void) fclose(outfp);
				(void) unlink(outmod);
				exit (1);
			}
		}
		(void) fgets(buffer,BUFSIZ,infp);
	}
}
