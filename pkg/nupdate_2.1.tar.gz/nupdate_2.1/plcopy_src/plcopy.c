	static char USMID[] = "@(#)plcopy/plcopy.c	81.0	09/26/93 19:03:21";
/*	COPYRIGHT CRAY RESEARCH, INC.
 *	UNPUBLISHED -- ALL RIGHTS RESERVED UNDER
 *	THE COPYRIGHT LAWS OF THE UNITED STATES.
 */
#include <stdio.h>
#include "modinfo.h"


char buffer[BUFSIZ];
char *direct=0;
struct list *modlist=0, *tail=0;

main(argc, argv)
int argc;
char *argv[];
{
	extern char *optarg;
	extern int optind;

	static char optstring[15] = "cd:i:no:q:";
	static char usage[100] =
	"Usage:  plcopy [-i in] [-o out] [-c] [-d dir] [-q path] [-n] [in] [out]";

	char *inpl, *outpl, *qstr, *temp;
	int c, makecos, makeold, qlen, type;

	FILE *fp;




	inpl = outpl = 0;
	makecos = makeold = 0;
	qstr = 0;


	while ((c=getopt(argc,argv,optstring)) != EOF)
	switch(c)
	{
		case 'i':
			inpl = optarg;
			fprintf(stderr,"-i usage will be discontinued.  Use arguments\n");
			continue;
		case 'o':
			outpl = optarg;
			fprintf(stderr,"-o usage will be discontinued.  Use arguments\n");
			continue;
		case 'c':
			makecos = 1;
			continue;
		case 'd':
			direct = optarg;
			if (!dir(direct))
			{
				fprintf(stderr, "plcopy:  %s is not a directory\n",direct);
				exit (1);
			}
			continue;
		case 'n':
			makeold = 1;
			continue;
		case 'q':
			qstr = (char *)malloc(strlen(optarg)+2);
			strcpy(qstr,optarg);
			qlen = strlen(qstr);
			continue;
		case '?':
			fprintf(stderr, "%s\n",usage);
			exit (2);
	}

	if (!inpl)
	{
		if (optind >= argc)
		{
			fprintf(stderr, "plcopy:  incorrect number of arguments\n");
			fprintf(stderr, "%s\n",usage);
			exit (2);
		}
		inpl = argv[optind++];
	}

	if (!outpl)
	{
		if (optind >= argc)
		{
			fprintf(stderr, "plcopy:  incorrect number of arguments\n");
			fprintf(stderr, "%s\n",usage);
			exit (2);
		}
		outpl = argv[optind++];
	}

	if (optind < argc)
	{
		fprintf(stderr, "plcopy:  incorrect number of arguments\n");
		fprintf(stderr, "%s\n",usage);
		exit (2);
	}


	/*  Check if the named inpl is an SCM pl  */

	if (dir(inpl))
	{
		temp = (char *)malloc(strlen(inpl)+6);
		strcpy(temp,inpl);
		strcat(temp,"/.SCM");
		if (dir(temp))
		{
			if (makecos)
			{
				fprintf(stderr, "plcopy:  Cannot make COS pl from SCM pl\n");
				exit (1);
			}
			if (makeold)
			{
				fprintf(stderr, "plcopy:  Cannot make old format pl from SCM pl\n");
				exit (1);
			}
			if (qstr)
			{
				/*  Make sure that qstr points to a directory  */
				temp = (char *)realloc(temp,strlen(inpl)+strlen(qstr)+2);
				strcpy(temp,inpl);
				strcat(temp,"/");
				strcat(temp,qstr);
				if (!dir(temp))
				{
					fprintf(stderr, "improper -q argument, %s is not a directory\n",
						temp);
					exit (1);
				}

				strcat(qstr,"/");
				qlen = strlen(qstr);
			}
			else
			{
				qlen = 0;
			}
			printf("plcopy:  converting scm pl to nupdate pl\n\n");
			scmtonupd(inpl,outpl,qstr,qlen);
			exit (0);
		}
		free(temp);
	}

	if (!dir(inpl))
	{
		/*  Check if this is a mod  */
		fp = fopen(inpl,"r");
		if (!fp)
		{
			fprintf(stderr, "plcopy:  unable to open file %s\n",inpl);
			exit (1);
		}

		if (fgets(buffer,BUFSIZ,fp) != NULL)
		{
			/*  Check if this is a mod  */
			(void) fclose(fp);
			if (strncmp(buffer,"*m",2) == 0 || strncmp(buffer,"*c",2) == 0 ||
			    strncmp(buffer,"*f",2) == 0 || strncmp(buffer,"*n",2) == 0)
			{
				if (!direct)
				{
					fprintf(stderr, "plcopy:  Warning:  No directory given, mods with\n");
					fprintf(stderr, "         depencencies may not be correct\n");
				}

				printf("plcopy:  converting scm mod\n\n");
				if (qstr)
				{
					strcat(qstr,"/");
					qlen = strlen(qstr);
				}
				scmmod(inpl,outpl,qstr,qlen);
				exit (0);
			}
			else if (strncmp(buffer,"*IDENT",6) == 0 || strncmp(buffer,"*/*",3) == 0)
			{
				if (!direct)
				{
					fprintf(stderr, "plcopy:  Warning:  No directory given, mods with\n");
					fprintf(stderr, "         depencencies may not be correct\n");
				}
				printf("plcopy:  converting usm mod\n\n");
				if (qstr)
				{
					strcat(qstr,"/");
					qlen = strlen(qstr);
				}
				usmmod(inpl,outpl,qstr,qlen);
				exit (0);
			}
		}
	}
				
	if (qstr)
	{
		fprintf(stderr, "plcopy:  -q option restricted to SCM pl\n");
		exit (1);
	}
	if (makecos)
	{
		printf("plcopy:  converting unicos format update pl to cos format\n\n");
		unicos2cos(inpl,outpl,makeold);
	}
	else
	{
		printf("plcopy:  converting cos format update pl to unicos format\n\n");
		cos2unicos(inpl,outpl,makeold);
	}
}
