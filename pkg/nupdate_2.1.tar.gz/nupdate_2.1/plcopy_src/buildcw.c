	static char USMID[] = "@(#)plcopy/buildcw.c	82.0	05/03/94 09:55:54";
/*	COPYRIGHT CRAY RESEARCH, INC.
 *	UNPUBLISHED -- ALL RIGHTS RESERVED UNDER
 *	THE COPYRIGHT LAWS OF THE UNITED STATES.
 */
#include "pltabs.h"

buildcw(buffer,bufptr,mode,numbcws,lasteof,lastrcw,lastcw)
union buffer_cw buffer[];
int bufptr,mode,numbcws,lasteof,lastrcw,lastcw;

{

	buffer[bufptr].control.mode = mode;
	buffer[bufptr].control.ubc = 0;
	buffer[bufptr].control.un1 = 0;
#ifdef SUN
	/*   
		When running on the SUNs, the words need to be aligned 
		on 32 bit boundaries, or they will force additional 
		words being pulled in.  This forces the block number 
		to be set in three parts 
	*/
	buffer[bufptr].control.pfi1 = (numbcws-lasteof) >> 12;
	buffer[bufptr].control.pfi2 = (numbcws-lasteof) & 0xFF;
	buffer[bufptr].control.pri = numbcws-lastrcw;
#else
	buffer[bufptr].control.pfi = numbcws-lasteof;
	buffer[bufptr].control.pri = numbcws-lastrcw;
#endif
	buffer[lastcw].control.fwi = bufptr-lastcw-1;
	return;
}
