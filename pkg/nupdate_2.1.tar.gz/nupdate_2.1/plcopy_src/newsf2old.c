	static char USMID[] = "@(#)plcopy/newsf2old.c	81.0	09/26/93 19:03:21";
/*	COPYRIGHT CRAY RESEARCH, INC.
 *	UNPUBLISHED -- ALL RIGHTS RESERVED UNDER
 *	THE COPYRIGHT LAWS OF THE UNITED STATES.
 */
#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include "pltabs.h"

newsf2old(inpl, outpl)
char *inpl, *outpl;

{

	/*
		This routine convers a new format UNICOS PL in
		single file format to an old cos format PL.  It does
		this by ensuring that all names in the TIDENT are
		8 characters or less, and contain no periods in
		them.  If they are invalid names, it will ask the
		user to enter an alternative name for this deck.
	*/

	char name[1000];
	char *namespc, *tptr;

	int bufptr, enddeck, lastcw, lasteof, lastrcw, i, namesplen;
	int numdecks=0, nummods=0, nw, nw2, oldpl, tidcnt, tidptr, ubc=0;
	long numbcws;

	struct
	{
		union
		{
			struct
			{
				char cc;
				char mc;
				unsigned pmc:1;
				unsigned un1:1;
				unsigned idcnt:14;
				unsigned idpos:32;
			}flags;
			char stuff[8];
		}word1;
		char date[8];
		union
		{
			struct
			{
				unsigned idpart1:32;
				unsigned idpart2:32;
			}flags;
			char stuff[8];
		}word3;
		union
		{
			struct
			{
				unsigned un2:32;
				unsigned un3:12;
				unsigned dw:10;
				unsigned pldw:10;
			}flags;
			char stuff[8];
		}word4;
		char unused[8];
		char signature[8];
	}plinfo;

	struct newidt tempid, *tident, *modids;
	struct oldidt *otident, *omodids;

	union
	{
		struct
		{
			unsigned part1:32;
			unsigned part2:32;
		}flags;
		char stuff[8];
	}one_word;

	union cardheader hdr;
	union
	{
		struct cw control;
		char stuff[8];
	}buffer[512];

	

	FILE *infp, *outfp;

	extern int validpl();
	extern char *strchr();




	/*  Open up the file and position to the PL table  */
	infp = fopen(inpl,"r b");
	if (!infp)
	{
		fprintf(stderr,"plcopy:  Unable to open file %s\n",inpl);
		exit (1);
	}
	(void) fseek(infp,-48,2);


	if (fread((char *)&plinfo,48,1,infp) != 1)
	{
		fprintf(stderr, "plcopy:  unable to read from file %s\n",inpl);
		exit (1);
	}

	/*  validate plinfo table  */
	oldpl = validinfo(&plinfo);
	if (oldpl)
	{
		(void) fclose(infp);
		old2old(inpl, outpl);
		return;
	}

	/*  Read in the TIDENT and the namespace  */
	if (fseek(infp,(plinfo.word1.flags.idpos*8),0) != 0)
	{
		fprintf(stderr, "plcopy:  Unable to position in file %s\n",inpl);
		exit (1);
	}

	tidcnt = plinfo.word1.flags.idcnt;

	tident = (struct newidt *)malloc(tidcnt*sizeof(struct newidt));
	modids = (struct newidt *)malloc(tidcnt*sizeof(struct newidt));

	while (tidcnt > 0)
	{
		if (fread((char *)&tempid, sizeof (struct newidt),1,infp) != 1)
		{
			fprintf(stderr, "plcopy:  unable to read from file %s\n",inpl);
			exit (1);
		}
		tempid.part3.flags.timestamp = 0;
		if (tempid.part2.flags.type != 0)
		{
			/*  This is a deck, copy into tident[numdecks]  */
			tident[numdecks] = tempid;
			numdecks++;
		}
		else
		{
			modids[nummods] = tempid;
			nummods++;
		}
		tidcnt--;
	}

	/*  Read in the name space  */
	if (fread(one_word.stuff,8,1,infp) != 1)
	{
		fprintf(stderr, "plcopy:  unable to read from %s\n",inpl);
		exit (1);
	}
	namesplen = one_word.flags.part2;
	namespc = (char *)malloc(namesplen*8+1);
	if (fread((char *)namespc,8,namesplen,infp) != namesplen)
	{
		fprintf(stderr, "plcopy:  unable to read namespace from %s\n",inpl);
		exit (1);
	}

	/*  Now that the tident and namespace is read, go through every deck and determine
	    whether the name is valid for an OLD pl.  If not, ask the user what to do with
	    it.
	*/

	otident = (struct oldidt *)malloc(numdecks*sizeof(struct oldidt));
	omodids = (struct oldidt *)malloc(nummods*sizeof(struct oldidt));

	for (tidptr=0;tidptr<numdecks;tidptr++)
	{
		tptr = namespc+(tident[tidptr].part1.flags.offset-1)*8;
		for (i=0;i<8;i++)
			name[i] = '\0';
		strncpy(name,tptr,tident[tidptr].part1.flags.namelen);
		while (strlen(name)>8 || strchr(name,'.'))
		{
			printf("%s is invalid OLD deck name, enter new one:  \n",name);
			clearerr(stdin);
			for (i=0;i<8;i++)
				name[i] = '\0';
			(void) gets(name);
		}
		for (i=0;i<8;i++)
			otident[tidptr].name[i] = name[i];
		otident[tidptr].part2.flags.type = tident[tidptr].part2.flags.type;
		otident[tidptr].part2.flags.t = tident[tidptr].part2.flags.t;
		otident[tidptr].part2.flags.m = tident[tidptr].part2.flags.m;
		otident[tidptr].part2.flags.un1 = tident[tidptr].part2.flags.un1;
		otident[tidptr].part2.flags.y = tident[tidptr].part2.flags.y;
		otident[tidptr].part2.flags.c = tident[tidptr].part2.flags.c;
		otident[tidptr].part2.flags.id = tident[tidptr].part2.flags.id;
	}
	for (tidptr=0;tidptr<nummods;tidptr++)
	{
		tptr = namespc+(modids[tidptr].part1.flags.offset-1)*8;
		for (i=0;i<8;i++)
			name[i] = '\0';
		strncpy(name,tptr,modids[tidptr].part1.flags.namelen);
		while (strlen(name)>8 || strchr(name,'.'))
		{
			printf("%s is invalid OLD identifier name, enter new one:  \n",name);
			clearerr(stdin);
			for (i=0;i<8;i++)
				name[i] = '\0';
			(void) gets(name);
		}
		for (i=0;i<8;i++)
			omodids[tidptr].name[i] = name[i];
		omodids[tidptr].part2.flags.type = modids[tidptr].part2.flags.type;
		omodids[tidptr].part2.flags.t = modids[tidptr].part2.flags.t;
		omodids[tidptr].part2.flags.m = modids[tidptr].part2.flags.m;
		omodids[tidptr].part2.flags.un1 = modids[tidptr].part2.flags.un1;
		omodids[tidptr].part2.flags.y = modids[tidptr].part2.flags.y;
		omodids[tidptr].part2.flags.c = modids[tidptr].part2.flags.c;
		omodids[tidptr].part2.flags.id = modids[tidptr].part2.flags.id;
		omodids[tidptr].part2.flags.pos = 0;
	}
	/*  Go through and read in every record, building control words as we go  */

	outfp = fopen(outpl,"w b");
	if (!outfp)
	{
		fprintf(stderr, "plcopy:  Cannot open %s\n",outpl);
		exit (1);
	}

	lastcw = tidptr = 0;

	/*  Build a BCW word  */
	buildbcw(buffer,0);
	lastcw=0;
	numbcws = lasteof = lastrcw = bufptr = 1;
	
	while (tidptr<numdecks)
	{
		if (fseek(infp,(tident[tidptr].part2.flags.pos*8),0) != 0)
		{
			fprintf(stderr, "plcopy:  Unable to position in file %s\n",inpl);
			unlink(outpl);
			exit (1);
		}

		/*  Set the position in the OLD tident  */
		otident[tidptr].part2.flags.pos = ftell(outfp)/8+bufptr-numbcws;

		enddeck = 0;
		while (!enddeck)
		{
			/*  Read in the header  */
			if (fread(hdr.stuff,8,1,infp) != 1)
			{
				fprintf(stderr, "plcopy:  Cannot read %s\n",name);
				unlink(outpl);
				exit (1);
			}

			if (hdr.flags.flags == 0 && hdr.flags.charcnt == 0 &&
				hdr.flags.seq1 == 0 && hdr.flags.seq2 == 0 &&
				hdr.flags.hdc == 0 && hdr.flags.id == 0)
			{
				enddeck = 1;
			}
			else
			{
				/*  Determine the number of words to read  */
				nw = (hdr.flags.charcnt+7)/8 + (hdr.flags.hdc+2)/4;
				ubc = ((((hdr.flags.charcnt+7)/8)*8)-hdr.flags.charcnt)*8;
				hdr.flags.charcnt = 0;
				for (i=0;i<8;i++)
					buffer[bufptr].stuff[i] = hdr.stuff[i];
				bufptr++;

				if (bufptr+nw <= 512)
				{
					/*  Read the entire record into buffer */
					if (fread(&buffer[bufptr],8,nw,infp) != nw)
					{
						fprintf(stderr, "plcopy:  Cannot read from %s\n",
							name);
						unlink(outpl);
						exit (1);
					}
					bufptr = bufptr+nw;
					/*  Set the unused bits to 0  */
					for (i=8-(ubc/8);i<8;i++)
						buffer[bufptr-1].stuff[i] = '\0';
					/*  Determine whether the RCW will fit */
					if (bufptr==512)
					{
						write_buff(buffer,lastcw,outfp,outpl);
						buildbcw(buffer,numbcws);
						bufptr = 1;
						lastcw = 0;
						numbcws++;
					}
					/*  Build an RCW  */
					buildcw(buffer,bufptr,8,numbcws,lasteof,lastrcw,lastcw);
					buffer[bufptr].control.ubc = ubc;
					ubc = 0;
					lastcw = bufptr;
					bufptr++;
					lastrcw = numbcws;
				}
				else
				{
					/*  Read in part of a record, write out the buffer, and
					read in the rest of the record  */
					nw2 = 512-bufptr;
					if (fread(&buffer[bufptr],8,nw2,infp) != nw2)
					{
						fprintf(stderr, "plcopy:  Cannot read from %s\n",
							name);
						unlink(outpl);
						exit (1);
					}
					write_buff(buffer,lastcw,outfp,outpl);
					buildbcw(buffer,numbcws);
					bufptr = 1;
					lastcw = 0;
					numbcws++;
					nw = nw-nw2;
					if (fread(&buffer[bufptr],8,nw,infp) != nw)
					{
						fprintf(stderr, "plcopy:  Cannot read from %s\n",
							name);
						unlink(outpl);
						exit (1);
					}
					bufptr = bufptr+nw;
					/*  Set the unused bits to 0  */
					for (i=8-(ubc/8);i<8;i++)
						buffer[bufptr-1].stuff[i] = '\0';
					/*  Build an RCW  */
					buildcw(buffer,bufptr,8,numbcws,lasteof,lastrcw,lastcw);
					buffer[bufptr].control.ubc = ubc;
					ubc = 0;
					lastcw = bufptr;
					bufptr++;
					lastrcw = numbcws;
				}
			}
			if (bufptr==512)
			{
				/*  This word needs to be written out  */
				write_buff(buffer,lastcw,outfp,outpl);
				buildbcw(buffer,numbcws);
				bufptr = 1;
				lastcw = 0;
				numbcws++;
			}
		}
		/*  We are at the end of the deck, create a EOF  */
		buildcw(buffer,bufptr,14,numbcws,lasteof,lastrcw,lastcw);
		lastcw = bufptr;
		bufptr++;
		lasteof = numbcws;
		if (bufptr==512)
		{
			/*  This word needs to be written out  */
			write_buff(buffer,lastcw,outfp,outpl);
			buildbcw(buffer,numbcws);
			bufptr = 1;
			lastcw = 0;
			numbcws++;
		}
		tidptr++;
	}

	/*  At the end of all decks, copy the OLD tident into the buffer */
	plinfo.word1.flags.idpos = ftell(outfp)/8+bufptr-numbcws;
	for (tidptr=0;tidptr<numdecks;tidptr++)
	{
		if (bufptr==512)
		{
			/*  This word needs to be written out  */
			write_buff(buffer,lastcw,outfp,outpl);
			buildbcw(buffer,numbcws);
			bufptr = 1;
			lastcw = 0;
			numbcws++;
		}
		/*  There are two scenarios  */
		if (bufptr<511)
		{
			/*  copy both words for this entry  */
			for (i=0;i<8;i++)
				buffer[bufptr].stuff[i] = otident[tidptr].name[i];
			bufptr++;
			for (i=0;i<8;i++)
				buffer[bufptr].stuff[i] = otident[tidptr].part2.stuff[i];
			bufptr++;
		}
		else
		{
			/*  copy 1 word for this entry, start a new block, and copy the last  */
			for (i=0;i<8;i++)
				buffer[bufptr].stuff[i] = otident[tidptr].name[i];
			write_buff(buffer,lastcw,outfp,outpl);
			buildbcw(buffer,numbcws);
			bufptr = 1;
			lastcw = 0;
			numbcws++;
			for (i=0;i<8;i++)
				buffer[bufptr].stuff[i] = otident[tidptr].part2.stuff[i];
			bufptr++;
		}
	}
	for (tidptr=0;tidptr<nummods;tidptr++)
	{
		if (bufptr==512)
		{
			/*  This word needs to be written out  */
			write_buff(buffer,lastcw,outfp,outpl);
			buildbcw(buffer,numbcws);
			bufptr = 1;
			lastcw = 0;
			numbcws++;
		}
		/*  There are two scenarios  */
		if (bufptr<511)
		{
			/*  copy both words for this entry  */
			for (i=0;i<8;i++)
				buffer[bufptr].stuff[i] = omodids[tidptr].name[i];
			bufptr++;
			for (i=0;i<8;i++)
				buffer[bufptr].stuff[i] = omodids[tidptr].part2.stuff[i];
			bufptr++;
		}
		else
		{
			/*  copy 1 word for this entry, start a new block, and copy the last  */
			for (i=0;i<8;i++)
				buffer[bufptr].stuff[i] = omodids[tidptr].name[i];
			write_buff(buffer,lastcw,outfp,outpl);
			buildbcw(buffer,numbcws);
			bufptr = 1;
			lastcw = 0;
			numbcws++;
			for (i=0;i<8;i++)
				buffer[bufptr].stuff[i] = omodids[tidptr].part2.stuff[i];
			bufptr++;
		}
	}

	/*  Now, lastly, create an EOR, EOF sequence, and copy in the plinfo table  */
	buildcw(buffer,bufptr,8,numbcws,lasteof,lastrcw,lastcw);
	lastcw = bufptr;
	bufptr++;
	lastrcw=numbcws;
	if (bufptr==512)
	{
		write_buff(buffer,lastcw,outfp,outpl);
		buildbcw(buffer,numbcws);
		bufptr = 1;
		lastcw = 0;
		numbcws++;
	}
	buildcw(buffer,bufptr,14,numbcws,lasteof,lastrcw,lastcw);
	lastcw = bufptr;
	bufptr++;
	lasteof = numbcws;
	if (bufptr==512)
	{
		write_buff(buffer,lastcw,outfp,outpl);
		buildbcw(buffer,numbcws);
		bufptr = 1;
		lastcw = 0;
		numbcws++;
	}
	/*  Now, copy in the plinfo words  */

	plinfo.word1.flags.cc = 'c';

	for (i=0;i<8;i++)
		buffer[bufptr].stuff[i] = plinfo.word1.stuff[i];
	bufptr++;
	if (bufptr==512)
	{
		write_buff(buffer,lastcw,outfp,outpl);
		buildbcw(buffer,numbcws);
		bufptr = 1;
		lastcw = 0;
		numbcws++;
	}

	strncpy(buffer[bufptr].stuff,plinfo.date,8);
	bufptr++;
	if (bufptr==512)
	{
		write_buff(buffer,lastcw,outfp,outpl);
		buildbcw(buffer,numbcws);
		bufptr = 1;
		lastcw = 0;
		numbcws++;
	}

	/*  Assume that the last id was the last mod in the modids table  */
	if (nummods>0)
	{
		for (i=0;i<8;i++)
			buffer[bufptr].stuff[i] = omodids[nummods-1].name[i];
	}
	else
	{
		for (i=0;i<8;i++)
			buffer[bufptr].stuff[i] = otident[numdecks-1].name[i];
	}
	bufptr++;
	if (bufptr==512)
	{
		write_buff(buffer,lastcw,outfp,outpl);
		buildbcw(buffer,numbcws);
		bufptr = 1;
		lastcw = 0;
		numbcws++;
	}

	/*  The datawidth for a PL transferred from new format to OLD HAS to be
	    variable length  */
	plinfo.word4.flags.dw = 0x3FF;
	plinfo.word4.flags.pldw = 0x3FF;

	for (i=0;i<8;i++)
		buffer[bufptr].stuff[i] = plinfo.word4.stuff[i];
	bufptr++;
	if (bufptr==512)
	{
		write_buff(buffer,lastcw,outfp,outpl);
		buildbcw(buffer,numbcws);
		bufptr = 1;
		lastcw = 0;
		numbcws++;
	}

	for (i=0;i<8;i++)
		buffer[bufptr].stuff[i] = plinfo.unused[i];
	bufptr++;
	if (bufptr==512)
	{
		write_buff(buffer,lastcw,outfp,outpl);
		buildbcw(buffer,numbcws);
		bufptr = 1;
		lastcw = 0;
		numbcws++;
	}

	for (i=0;i<8;i++)
		buffer[bufptr].stuff[i] = plinfo.signature[i];
	bufptr++;
	if (bufptr==512)
	{
		write_buff(buffer,lastcw,outfp,outpl);
		buildbcw(buffer,numbcws);
		bufptr = 1;
		lastcw = 0;
		numbcws++;
	}

	/*  Create an EOR, EOF and EOD  */
	buildcw(buffer,bufptr,8,numbcws,lasteof,lastrcw,lastcw);
	lastcw = bufptr;
	lastrcw=numbcws;
	bufptr++;
	if (bufptr==512)
	{
		write_buff(buffer,lastcw,outfp,outpl);
		buildbcw(buffer,numbcws);
		bufptr = 1;
		lastcw = 0;
		numbcws++;
	}

	buildcw(buffer,bufptr,14,numbcws,lasteof,lastrcw,lastcw);
	lastcw = bufptr;
	bufptr++;
	lasteof = numbcws;
	if (bufptr==512)
	{
		write_buff(buffer,lastcw,outfp,outpl);
		buildbcw(buffer,numbcws);
		bufptr = 1;
		lastcw = 0;
		numbcws++;
	}

	buildcw(buffer,bufptr,15,numbcws,lasteof,lastrcw,lastcw);
	buffer[bufptr].control.fwi = 0;

	if (fwrite(buffer,8,bufptr+1,outfp) != bufptr+1)
	{
		fprintf(stderr, "plcopy:  Cannot write to %s\n",outpl);
		unlink(outpl);
		exit (1);
	}
	(void) fclose(outfp);
	return;
}
