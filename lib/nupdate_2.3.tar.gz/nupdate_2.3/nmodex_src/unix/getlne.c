	static char USMID[] = "@(#)nmodex/unix/getlne.c	81.0	09/26/93 18:39:01";

	/*
		COPYRIGHT CRAY RESEARCH, INC.
		UNPUBLISHED -- ALL RIGHTS RESERVED UNDER
		THE COPYRIGHT LAWS OF THE UNITED STATES
	*/
#include <stdio.h>
/*  This routine reads a line from dsp and copies it into
    buf.  nchars, as input, is the maximum number of characters
    to return as output the number of characters actually read.
    On exit, status has one of the following values:
    -1 Characters remain in record, 0: a \n was encountered,
    or 2: End of file.
 */
#ifdef sun
getlne_(dsp,buf,nchars,status)
#else
GETLNE(dsp,buf,nchars,status)
#endif
long **dsp;
char *buf;
long *nchars;
long *status;
{

	if (fgets(buf,*nchars+1,(FILE *)*dsp))
	{
		*nchars = strlen(buf)-1;
		if (buf[*nchars] != '\n')
		{
			if (getc((FILE *)*dsp) != EOF)
			{
				/*
					No end of line encountered, or line
					greater than 512 characters.
				*/
				*status = -1;
			}
			else
			{
				*nchars = *nchars+1;
				*status = 0;
			}
		}
		else
		{
			*status = 0;
		}
	}
	else
	{
		*status = 2;
	}
	return;
}
