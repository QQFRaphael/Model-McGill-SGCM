	static char USMID[] = "@(#)nmodex/unix/getdate.c	81.0	09/26/93 18:39:01";

	/*
		COPYRIGHT CRAY RESEARCH, INC.
		UNPUBLISHED -- ALL RIGHTS RESERVED UNDER
		THE COPYRIGHT LAWS OF THE UNITED STATES.
	*/
#include <sys/types.h>
#include <time.h>
#ifdef sun
double getdate_()
#else
long GETDATE()
#endif

{
	struct tm *mtm;
	time_t clock;
	extern struct tm *localtime();
	extern time_t time();
        static char *mo[12] = {"Jan", "Feb", "Mar", "Apr", "May",
                               "Jun", "Jul", "Aug", "Sep", "Oct",
                               "Nov", "Dec"};
        union {
#ifdef _32BIT
		double res;
#else
		long res;
#endif
		char res1[8];
	} result;

	clock = time(0);
	mtm = localtime(&clock);
        sprintf(result.res1,"%.2d%s%.2d",mtm->tm_mday,
           mo[mtm->tm_mon],mtm->tm_year);
	return(result.res);
}
