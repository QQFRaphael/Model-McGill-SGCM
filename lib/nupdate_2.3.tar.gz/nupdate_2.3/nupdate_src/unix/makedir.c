	static char USMID[] = "@(#)nupdate/unix/makedir.c	81.0	09/26/93 18:54:06";
/*      COPYRIGHT CRAY RESEARCH, INC.
 *      UNPUBLISHED -- ALL RIGHTS RESERVED UNDER
 *      THE COPYRIGHT LAWS OF THE UNITED STATES.
 */
#include <sys/types.h>
#include <sys/stat.h>
#include <errno.h>
#include "nupdate.h"

#ifdef sun
f_int makedir_(path)
#else
f_int MAKEDIR(path)
#endif
char *path;
{
        int status;

        status = mkdir(path,0755);

        if (status != 0 && errno == EEXIST) status = 0;

	return status;
}
