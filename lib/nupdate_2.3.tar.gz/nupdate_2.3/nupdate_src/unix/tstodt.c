	static char USMID[] = "@(#)nupdate/unix/tstodt.c	81.0	09/26/93 18:54:06";
/*      COPYRIGHT CRAY RESEARCH, INC.
 *      UNPUBLISHED -- ALL RIGHTS RESERVED UNDER
 *      THE COPYRIGHT LAWS OF THE UNITED STATES.
 */ 
#include <stdio.h>
#include <string.h>
#include <sys/types.h>
#include <time.h>
#include "nupdate.h"
#ifdef sun
void tstodt_(ts,timedate)
#else
void TSTODT(ts,timedate)
#endif
f_int *ts;
char timedate[16];

{
	struct tm *mtm;
	extern struct tm *localtime();
	char tmp[20];

	mtm = localtime(ts);
	sprintf(tmp,"%.2d/%.2d/%.2d%.2d:%.2d:%.2d",mtm->tm_mon+1,
	   mtm->tm_mday,(mtm->tm_year)%100,
           mtm->tm_hour,mtm->tm_min,mtm->tm_sec);
	strncpy(timedate,tmp,16);
	return;
}
