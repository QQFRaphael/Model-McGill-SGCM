	static char USMID[] = "@(#)nupdate/unix/gettime.c	81.0	09/26/93 18:54:06";
/*      COPYRIGHT CRAY RESEARCH, INC.
 *      UNPUBLISHED -- ALL RIGHTS RESERVED UNDER
 *      THE COPYRIGHT LAWS OF THE UNITED STATES.
 */
#include <time.h>
#include "nupdate.h"

#ifdef sun
f_int gettime_()
#else
f_int GETTIME()
#endif

{
	return ((f_int)time(0));
}
