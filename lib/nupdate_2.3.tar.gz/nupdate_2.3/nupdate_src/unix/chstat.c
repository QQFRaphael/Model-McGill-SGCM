	static char USMID[] = "@(#)nupdate/unix/chstat.c	81.0	09/26/93 18:54:06";
/*      COPYRIGHT CRAY RESEARCH, INC.
 *      UNPUBLISHED -- ALL RIGHTS RESERVED UNDER
 *      THE COPYRIGHT LAWS OF THE UNITED STATES.
 */    
#include <sys/types.h>
#include <sys/stat.h>
#include "nupdate.h"

#ifdef sun
f_int chstat_(path)
#else
f_int CHSTAT(path)
#endif
char *path;
{
	struct stat buf;

	if (stat(path,&buf)==0)
	{
		
		if ((buf.st_mode & 0040000) == 0) {
			return (0);
		}
		else
		{
			return (1);
		}
	}
	else
	{
		return(0);
	}
}
