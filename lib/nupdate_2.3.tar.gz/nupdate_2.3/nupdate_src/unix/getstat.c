	static char USMID[] = "@(#)nupdate/unix/getstat.c	81.0	09/26/93 18:54:06";
/*      COPYRIGHT CRAY RESEARCH, INC.
 *      UNPUBLISHED -- ALL RIGHTS RESERVED UNDER
 *      THE COPYRIGHT LAWS OF THE UNITED STATES.
 */
#include <sys/types.h>
#include <sys/stat.h>
#include "nupdate.h"

#ifdef sun
f_int getstat_(path)
#else
f_int GETSTAT(path)
#endif
char *path;
{
	struct stat buf;

	if (stat(path,&buf)==0)
	{
		return((f_int)buf.st_mtime);
	}
	else
	{
		return((f_int)time(0));
	}
}
