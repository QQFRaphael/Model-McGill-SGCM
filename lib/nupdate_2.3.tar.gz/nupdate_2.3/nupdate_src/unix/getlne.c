	static char USMID[] = "@(#)nupdate/unix/getlne.c	81.0	09/26/93 18:54:06";
/*      COPYRIGHT CRAY RESEARCH, INC.
 *      UNPUBLISHED -- ALL RIGHTS RESERVED UNDER
 *      THE COPYRIGHT LAWS OF THE UNITED STATES.
 */
#include <stdio.h>
#include <string.h>
#include "nupdate.h"
/*  This routine reads a line from dsp and copies it into
    buf.  nchars, as input, is the maximum number of characters
    to return as output the number of characters actually read.
    On exit, status has one of the following values:
    -1 Characters remain in record, 0: a \n was encountered,
    or 2: End of file.
 */
#ifdef sun
void getlne_(dsp,buf,nchars,status)
#else
void GETLNE(dsp,buf,nchars,status)
#endif
FILE **dsp;
char *buf;
f_int *nchars;
f_int *status;
{
	if (fgets(buf,5000,*dsp))
	{

		if (strlen(buf)-1 > *nchars)
		{
			*status = -1;
		}
		else
		{
			*nchars = strlen(buf)-1;
			*status = 0;
		}
	}
	else
	{
		*status = 2;
	}
	return;
}
