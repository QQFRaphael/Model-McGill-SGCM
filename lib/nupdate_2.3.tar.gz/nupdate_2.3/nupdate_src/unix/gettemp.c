	static char USMID[] = "@(#)nupdate/unix/gettemp.c	81.0	09/26/93 18:54:06";
/*      COPYRIGHT CRAY RESEARCH, INC.
 *      UNPUBLISHED -- ALL RIGHTS RESERVED UNDER
 *      THE COPYRIGHT LAWS OF THE UNITED STATES.
 */
#include <stdio.h>
 /*
     This routine is the tempnam interface.  Since it is necessary
     that the fortran code for UPDATE be free of fortran pointer
     variables, this routine must return the temporary file name.
  */
#ifdef sun
void gettemp_(name,prefix)
#else
void GETTEMP(name,prefix)
#endif
char *name, *prefix;
{
        char *value;
        value = tempnam(0,prefix);
        while (*value != '\0')
           *name++ = *value++;
}
