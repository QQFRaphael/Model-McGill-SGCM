typedef int f_int;        /* Fortran integer type */
typedef float f_float;    /* Fortran float type */
typedef double f_double;  /* Fortran double precision type */
typedef long f_pointer;   /* Fortran pointer type */
