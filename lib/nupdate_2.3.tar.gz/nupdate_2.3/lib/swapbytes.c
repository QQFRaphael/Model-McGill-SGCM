#include <stdio.h>
#include <stdlib.h>
#include "nupdate.h"

void swap_bytes_(void *buf, f_int *nbytesf, f_int *nf)
{
   int i, j, nbytes, n;
   unsigned char temp, *cbuf;

   nbytes = *nbytesf;
   n = *nf;

   cbuf = (unsigned char *) buf;

   for (i=0; i<n ; i++)
   {
      for (j=0; j<nbytes/2; j++)
      {
         temp = cbuf[j];
         cbuf[j] = cbuf[nbytes-j-1];
         cbuf[nbytes-j-1] = temp;
      }
      cbuf += nbytes;
   }

   return;
}
