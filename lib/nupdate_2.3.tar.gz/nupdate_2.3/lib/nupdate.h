typedef long f_pointer;   /* Fortran pointer type */
typedef int f_int;        /* Fortran integer type */
typedef float f_float;    /* Fortran float type */
#if defined EBS_LONG
   typedef long f_double;  /* Fortran 8 byte storage type */
#elif defined EBS_LONGLONG
   typedef long long f_double;  /* Fortran 8 byte storage type */
#else
   typedef double f_double;  /* Fortran 8 byte storage type */
#endif
