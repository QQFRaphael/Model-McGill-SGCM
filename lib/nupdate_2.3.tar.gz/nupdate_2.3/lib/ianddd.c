/*      This routine takes two double precision numbers,
        ands them together and returns an integer value.
 */

#include "nupdate.h"

f_int
ianddd_(d1,d2)
f_int d1[], d2[];
{
#ifdef __little__endian__
        int b=0;
#else
        int b=1;
#endif
        return (d1[b] & d2[b]);
}
