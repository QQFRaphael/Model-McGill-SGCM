#include <stdio.h>
#include "nupdate.h"

/*     ftell.c       */

f_int
ftell_(fp)
FILE **fp;
{
	long ftell();
	return((f_int)ftell(*fp));
}
