/*      This routine takes two double precision numbers, ors
        them together and returns a doubleprecision value.
 */

#include "nupdate.h"

f_double
dordd_(d1,d2)
f_int d1[], d2[];
{
        union {
                 f_double res;
                 f_int res1[2];
              } foo;

              foo.res1[0] = d1[0] | d2[0];
              foo.res1[1] = d1[1] | d2[1];
              return (foo.res);
}
