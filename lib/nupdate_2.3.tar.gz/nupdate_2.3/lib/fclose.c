#include <stdio.h>
#include "nupdate.h"

/*   flclose    */

f_int
fclose_(fp)
FILE **fp;
{
	return((f_int)fclose(*fp));
}
