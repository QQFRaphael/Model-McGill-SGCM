#include <stdlib.h>
#include <unistd.h>
#include "nupdate.h"

/*    unlink.c        */

void unlink_(path)
char *path;
{
	unlink(path);
}
