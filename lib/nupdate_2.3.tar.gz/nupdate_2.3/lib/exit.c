#include <stdlib.h>
#include "nupdate.h"

/*    exit.c        */

void exit_(status)
f_int *status;
{
	exit((int)*status);
}
