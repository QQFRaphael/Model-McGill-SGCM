#include <stdio.h>
#include "nupdate.h"

/*    fwrite.c       */

f_int
fwrite_(ptr, size, n, fp)
char *ptr;
f_int *size, *n;
FILE **fp;
{
	return((f_int)fwrite(ptr,
           (int)*size, (int)*n, *fp));
}
