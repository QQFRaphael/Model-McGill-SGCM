	static char USMID[] = "@(#)sunlib/ishiftrd.c	0.1	03/26/90 11:58:06";



/*
	ishiftrd.  This routine takes a double precision
	value, shifts it right VALUE bits, and returns an
	integer value.
*/

#include "nupdate.h"

f_int
ishiftrd_(d1,value)
f_int d1[], *value;
{
#ifdef __little__endian__
        int a=1,b=0;
#else
        int a=0,b=1;
#endif

	f_int res;

	if (*value==32)
	{
		res = d1[a];
	}
        else if (*value>32)
        {
		/*
			shifting right more than 32 bits sets the shifted value
			of the high order bits to the low order bits.
		*/
		res = (unsigned)d1[a]>>(*value-32);
	}
	else if (*value == 0)
	{
		/*
			Shifting exactly 0 bits returns the low order bits.
		*/
		res = d1[b];
	}
	else
	{
		/*
			shifting right fewer than 32 bits causing a combination
			of the shifted low and high order bits.
		*/
		res = (d1[a]<<(32-*value)) |
			((unsigned)d1[b]>>*value);
	}
	return (res);
}
