/*	static char USMID[] = "@(#)plcopy/pltabs.h	82.0	05/03/94 09:55:54"  */
/*	COPYRIGHT CRAY RESEARCH, INC.
 *	UNPUBLISHED -- ALL RIGHTS RESERVED UNDER
 *	THE COPYRIGHT LAWS OF THE UNITED STATES.
 */
struct newplinfot
{
	char cc;
	char mc;
	unsigned pmc:1;
	unsigned un1:1;
	unsigned idcnt:14;
	unsigned idpos:32;
	char date[8];
	unsigned idpart1:32;
	unsigned idpart2:32;
	unsigned un2:32;
	unsigned un3:12;
	unsigned dw:10;
	unsigned pldw:10;
	char unused[8];
	char signature[8];
};
struct plinfot
{
	char cc;
	char mc;
	unsigned pmc:1;
	unsigned un1:1;
	unsigned idcnt:14;
	unsigned idpos:32;
	char date[8];
	char id[8];
	unsigned un2:32;
	unsigned un3:12;
	unsigned dw:10;
	unsigned pldw:10;
	char unused[8];
	char signature[8];
};

struct oldidt
{
	char name[8];
	union
	{
		struct
		{
			unsigned type:8;
			unsigned t:1;
			unsigned m:1;
			unsigned un1:6;
			unsigned y:1;
			unsigned c:1;
			unsigned id:14;
			unsigned pos:32;
		}flags;
		char stuff[8];
	}part2;
};

struct newidt
{
	union
	{
		struct
		{
			unsigned hash:16;
			unsigned namelen:8;
			unsigned newun1:5;
			unsigned dkdw1:3;
			unsigned dkdw:5;
			unsigned lang:6;
			unsigned ns:1;
			unsigned offset:20;
		}flags;
		char stuff[8];
	}part1;
	union
	{
		struct
		{
			unsigned type:8;
			unsigned t:1;
			unsigned m:1;
			unsigned un1:6;
			unsigned y:1;
			unsigned c:1;
			unsigned id:14;
			unsigned pos:32;
		}flags;
		char stuff[8];
	}part2;
	union
	{
		struct
		{
			unsigned un2:32;
			unsigned timestamp:32;
		}flags;
		char stuff[8];
	}part3;
};

union cardheader
{
	struct
	{
		unsigned flags:8;
		unsigned charcnt:9;
		unsigned seq1:15;
		unsigned seq2:2;
		unsigned hdc:14;
		unsigned id:16;
	}flags;
	char stuff[8];
};

struct cw
{
	unsigned mode:4;
	unsigned ubc:6;
	unsigned un1:10;
#ifdef SUN
	unsigned pfi1:12;
	unsigned pfi2:8;
	unsigned pri:15;
#else
	unsigned pfi:20;
	unsigned pri:15;
#endif
	unsigned fwi:9;
};

union buffer_cw
{
	struct cw control;
	char stuff[8];
};
	
