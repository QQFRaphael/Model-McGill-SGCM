/*	static char USMID[] = "@(#)plcopy/pl.h	81.0	09/26/93 19:03:21"  */
/*	COPYRIGHT CRAY RESEARCH, INC.
 *	UNPUBLISHED -- ALL RIGHTS RESERVED UNDER
 *	THE COPYRIGHT LAWS OF THE UNITED STATES.
 */
struct list
{
	char *name;
	int id;
	struct list *next;
};

struct cardheader
{
	unsigned act:1;
	unsigned flags:7;
	unsigned charcnt:9;
	unsigned seq1:15;
	unsigned seq2:2;
	unsigned hdc:14;
	unsigned idact:1;
	unsigned id:15;
};

struct idt
{
	unsigned hash:16;
	unsigned namelen:8;
	unsigned un1:5;
	unsigned dkdw1:3;
	unsigned dkdw:5;
	unsigned lang:6;
	unsigned ns:1;
	unsigned offset:20;

	unsigned type:8;
	unsigned t:1;
	unsigned m:1;
	unsigned un2:6;
	unsigned y:1;
	unsigned c:1;
	unsigned id:14;
	unsigned pos:32;
	unsigned un3:32;
	unsigned timestamp:32;
};

struct plinfot
{
	char cc;
	char mc;
	unsigned pmc:1;
	unsigned un1:1;
	unsigned idcnt:14;
	unsigned idpos:32;
	char date[8];
	unsigned idpart1:32;
	unsigned idpart2:32;
	unsigned un2:32;
	unsigned un3:12;
	unsigned dw:10;
	unsigned pldw:10;
	char unused[8];
	char signature[8];
};
