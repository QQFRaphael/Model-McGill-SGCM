	static char USMID[] = "@(#)plcopy/readoids.c	81.0	09/26/93 19:03:21";
/*	COPYRIGHT CRAY RESEARCH, INC.
 *	UNPUBLISHED -- ALL RIGHTS RESERVED UNDER
 *	THE COPYRIGHT LAWS OF THE UNITED STATES.
 */
#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include "pltabs.h"

readoids(tident,modids,numdecks,nummods,tidcnt,infp,inpl,next)
struct oldidt **tident, **modids;
int *numdecks, *nummods, tidcnt, *next;
FILE *infp;
char *inpl;

{

	/*  This routine is responsible for reading in the old format
	    TIDENT table.  */

	char *cw;

	struct oldidt tempid;

	extern char *getcw();




	/*  Allocate twice the space needed for the tident.  One is for the decks,
	    the other is for the mods  */
	*tident = (struct oldidt *)malloc(tidcnt*sizeof(struct oldidt));
	*modids = (struct oldidt *)malloc(tidcnt*sizeof(struct oldidt));
	*nummods = 0;
	*numdecks = 0;
	while (tidcnt > 0)
	{
		if (*next>1)
		{
			/*  The entire next entry is before the next control word  */
			if (fread((char *)&tempid,sizeof(struct oldidt),1,infp) != 1)
			{
				fprintf(stderr, "plcopy:  unable to read from PL %s\n",inpl);
				exit (1);
			}
			*next = *next-2;
		}
		else if (*next == 1)
		{
			/*  the control word is between the two words of the TIDENT entry  */
			if (fread((char *)&tempid,8,1,infp) != 1)
			{
				fprintf(stderr, "plcopy:  unable to read from PL %s\n",inpl);
				exit (1);
			}
			cw = getcw(infp,next);
			if (strcmp(cw,"bcw") || *next < 1)
			{
				fprintf(stderr, "plcopy:  invalid control word in %s\n",inpl);
				exit (1);
			}
			if (fread(tempid.part2.stuff,8,1,infp) != 1)
			{
				fprintf(stderr, "plcopy:  unable to read from PL %s\n",inpl);
				exit (1);
			}
			*next = *next-1;
		}
		else
		{
			/*  There is a control word, followed the by tident entry  */
			cw = getcw(infp, next);
			if (strcmp(cw,"bcw") || *next <= 1)
			{
				fprintf(stderr, "plcopy:  invalid control word in %s\n",inpl);
				exit (1);
			}
			if (fread((char *)&tempid,8,2,infp) != 2)
			{
				fprintf(stderr, "plcopy:  unable to read from PL %s\n",inpl);
				exit (1);
			}
			*next = *next-2;
		}
		if (tempid.part2.flags.type != 0)
		{
			/*  This is a deck, copy all information into tident[numdecks] */
			(*tident)[*numdecks] = tempid;
			*numdecks = *numdecks+1;
		}
		else
		{
			/*  This is a mod identifier, set to -1  */
			(*modids)[*nummods] = tempid;
			*nummods = *nummods+1;
		}
		tidcnt--;
	}
	return;
}
