	static char USMID[] = "@(#)plcopy/processdk.c	81.0	09/26/93 19:03:21";
/*	COPYRIGHT CRAY RESEARCH, INC.
 *	UNPUBLISHED -- ALL RIGHTS RESERVED UNDER
 *	THE COPYRIGHT LAWS OF THE UNITED STATES.
 */
#include <stdio.h>
#include "pl.h"

int
processdk(deckname,filefp,outfp)
char *deckname;
FILE *filefp, *outfp;

{

	extern struct list *decks, *mods, *decktail, *modstail;
	extern int numdecks, nummods;

	int i, nw, deckid;
	char buffer[1000], *deckbase, *id, *line, *ptr, *seq;

	struct list *p;
	struct cardheader header;


	extern char *strchr(), *strrchr();



	/*
		This routine processes the given deck.  It reas through the
		file, converting the SCM format to the id/seq number and the
		text portion.  All of these decks are automatically variable
		length in nature.
	*/


	/*  This information is always the same  */
	header.act = 1;
	header.flags = 0;
	header.hdc = 1;
	header.idact = 1;


	/*  In SCM, the ID written in the source file is the basename of the deckname */
	deckbase = strrchr(deckname,'/');
	if (!deckbase)
	{
		deckbase = deckname;
	}
	else
	{
		deckbase++;
	}

	/*  Add this deck name to the identifier list  */
	if (!decks)
	{
		decks = (struct list *)malloc(sizeof(struct list));
		decktail = decks;
		p = decks;
	}
	else
	{
		decktail->next = (struct list *)malloc(sizeof(struct list));
		decktail = decktail->next;
		p = decktail;
	}
	p->name = (char *)malloc(strlen(deckname)+1);
	strcpy(p->name,deckname);
	p->id = numdecks+nummods;
	p->next = 0;
	deckid = p->id;
	numdecks++;


	/*  Now, create the buffer of the (MC)DECK name,DW=*  */
	buffer[0] = 0252;
	buffer[1] = '\0';
	strcat(buffer,"DECK ");
	strcat(buffer,deckname);
	strcat(buffer,",DW=*");

	/*  Set card specific information  */
	header.id = p->id;
	header.seq1 = 0;
	header.seq2 = 1;
	header.charcnt = strlen(buffer);

	/*  Pad with nulls  */
	for (i=0;i<7;i++)
	{
		buffer[header.charcnt+i] = ' ';
	}

	if (fwrite(&header,sizeof(struct cardheader),1,outfp) != 1)
	{
		fprintf(stderr, "plcopy:  unable to write to %s\n",deckname);
		return(0);
	}
	nw = (header.charcnt+7)/8;
	if (fwrite(buffer,8,nw,outfp) != nw)
	{
		fprintf(stderr, "plcopy:  unable to write to %s\n",deckname);
		return(0);
	}

	/*  If there is a period in the base portion of the deckname, truncate it  */
	ptr = strchr(deckbase,'.');
	if (ptr) ptr[0] = '\0';
	


	while (fgets(buffer,1000,filefp))
	{
		/*  get rid of the new line  */
		buffer[strlen(buffer)-1] = '\0';

		/*  The format for SCM is 24 characters of id, following by the line */
		line = buffer+24;
		if (strlen(line) > 512)
		{
			fprintf(stderr, "plcopy:  line %s is too long\n",buffer);
			return(0);
		}

		/*  Trim id at first blank  */
		ptr = strchr(buffer,' ');
		if (!ptr)
		{
			fprintf(stderr, "plcopy:  Bad format for %s\n",deckname);
			return(0);
		}
		ptr[0] = '\0';

		id = buffer;
		ptr = strrchr(id,'.');
		if (!ptr)
		{
			fprintf(stderr, "plcopy:  Bad format for %s\n",deckname);
			return(0);
		}
		ptr[0] = '\0';
		seq = ptr+1;

		/*
			Now that we have the identifier name, search through the two
			tables to determine if it already exists.
		*/

		if (strcmp(id,deckbase) == 0)
		{
			/*
				This identifier is the same as the deck
				name.
			*/
			header.id = deckid;
			/*
				Increase sequence number by one on deck names
				since there is a new deck line added.
			*/
			i = atol(seq)+1;
		}
		else
		{
			/*
				Search through the mod identifiers to find it.
				If it is not found, then add a new entry
				to the modids.
			*/
			p = mods;
			header.id = 0;
			while (p && !header.id)
			{
				if (strcmp(p->name,id)==0)
				{
					/*  This is a match.  */
					header.id = p->id;
				}
				else
				{
					p = p->next;
				}
			}
			if (!header.id)
			{
				/*  Add an entry to the mods.  */
				if (!mods)
				{
					mods = (struct list *)malloc(sizeof(struct list));
					modstail = mods;
					p = mods;
				}
				else
				{
					modstail->next = (struct list *)malloc(sizeof(struct list));
					modstail = modstail->next;
					p = modstail;
				}
				p->name = (char *)malloc(strlen(id)+1);
				strcpy(p->name,id);
				p->id = numdecks+nummods;
				p->next = 0;
				nummods++;
			}
			header.id = p->id;
			i = atol(seq);
		}
		/* i contains the sequence number */
		header.seq1 = i>>2;
		header.seq2 = i & 03;
		header.charcnt = strlen(line);

		/*  Pad with nulls */
		for (i=0;i<7;i++)
		{
			line[header.charcnt+i] = ' ';
		}
		if (fwrite(&header,sizeof(struct cardheader),1,outfp) != 1)
		{
			fprintf(stderr, "plcopy:  unable to write to %s\n",deckname);
			return(0);
		}
		nw = (header.charcnt+7)/8;
		if (fwrite(line,8,nw,outfp) != nw)
		{
			fprintf(stderr, "plcopy:  unable to write to %s\n",deckname);
			return(0);
		}
	}

	/*
		Now that the deck is processed, write out a single
		word of nulls.
	*/
	for (i=0;i<8;i++)
		buffer[i] = '\0';
	if (fwrite(buffer,8,1,outfp) != 1)
	{
		fprintf(stderr, "plcopy:  unable to write to %s\n",deckname);
		return(0);
	}
	return(1);
}
