	static char USMID[] = "@(#)plcopy/trim.c	81.0	09/26/93 19:03:21";
/*	COPYRIGHT CRAY RESEARCH, INC.
 *	UNPUBLISHED -- ALL RIGHTS RESERVED UNDER
 *	THE COPYRIGHT LAWS OF THE UNITED STATES.
 */

trim(buffer)
char buffer[];

{
	char *tptr;

	buffer[strlen(buffer)-1] = '\0';
	tptr = &buffer[strlen(buffer)-1];
	while (tptr[0] == ' ' || tptr[0] == '\t')
	{
		tptr[0] = '\0';
		tptr--;
	}
	return;
}
