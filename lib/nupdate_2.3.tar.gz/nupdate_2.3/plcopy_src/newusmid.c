	static char USMID[] = "@(#)plcopy/newusmid.c	81.0	09/26/93 19:03:21";
/*	COPYRIGHT CRAY RESEARCH, INC.
 *	UNPUBLISHED -- ALL RIGHTS RESERVED UNDER
 *	THE COPYRIGHT LAWS OF THE UNITED STATES.
 */
#include <stdio.h>
newusmid(buffer,newid1,newid2,basedeck,deck,qlen)
char buffer[];
char **newid1, **newid2;
char *basedeck, *deck;
int qlen;

{

	extern char *direct;

	char *tptr, *id, *id2, *seq;
	char newseq[10];
	extern char *scmdep(), *strrchr();




	tptr = &buffer[3];
	while (tptr[0] == ' ' || tptr[0] == '\t') tptr++;
	id = tptr;
	tptr = strrchr(id,',');
	if (tptr)
	{
		tptr[0] = '\0';
		id2 = tptr+1;
	}
	else
	{
		id2 = 0;
	}
	tptr = strrchr(id,'.');
	if (!tptr)
	{
		fprintf(stderr, "plcopy:  Error in format of mod\n");
		fprintf(stderr, "%s\n",buffer);
		return(0);
	}
	tptr[0] = '\0';
	seq = tptr+1;
	if (strcmp(id,basedeck)==0)
	{
		/*  this is the same as the deckname, substitute the
		    full deck name and add 1 to the sequence number  */
		*newid1 = (char *)malloc(strlen(deck)+1+strlen(seq)+2);
		strcpy(*newid1,deck);
		strcat(*newid1,".");
		sprintf(newseq,"%d",atol(seq)+1);
		strcat(*newid1,newseq);
	}
	else
	{
		*newid1 = 0;
		if (direct)
		{
			/*  Check if this mod was added after the permapply  */
			*newid1 = scmdep(id,seq,deck,qlen);
		}
		if (!*newid1)
		{
			/*  copy the old id */
			*newid1 = (char *)malloc(strlen(id)+1+strlen(seq)+1);
			strcpy(*newid1,id);
			strcat(*newid1,".");
			strcat(*newid1,seq);
		}
	}
	if (id2)
	{
		/*  Process the second id */
		tptr = strrchr(id2,'.');
		if (!tptr)
		{
			fprintf(stderr, "plcopy:  Error in format of mod\n");
			fprintf(stderr, "%s\n",buffer);
			return(0);
		}
		tptr[0] = '\0';
		seq = tptr+1;
		if (strcmp(id2,basedeck)==0)
		{
			/*  this is the same as the deckname, substitute the
		    	full deck name and add 1 to the sequence number  */
			*newid2 = (char *)malloc(strlen(deck)+1+strlen(seq)+2);
			strcpy(*newid2,deck);
			strcat(*newid2,".");
			sprintf(newseq,"%d",atol(seq)+1);
			strcat(*newid2,newseq);
		}
		else
		{
			*newid2 = 0;
			if (direct)
			{
				*newid2 = scmdep(id2,seq,deck,qlen);
			}
			if (!*newid2)
			{
				*newid2 = (char *)malloc(strlen(id2)+1+strlen(seq)+1);
				strcpy(*newid2,id2);
				strcat(*newid2,".");
				strcat(*newid2,seq);
			}
		}
	}
	else
	{
		*newid2 = 0;
	}
	return(1);
}
