	static char USMID[] = "@(#)plcopy/getcw.c	81.0	09/26/93 19:03:21";
/*	COPYRIGHT CRAY RESEARCH, INC.
 *	UNPUBLISHED -- ALL RIGHTS RESERVED UNDER
 *	THE COPYRIGHT LAWS OF THE UNITED STATES.
 */
#include <stdio.h>
#include "pltabs.h"


char
*getcw(fp, next)
FILE *fp;
int *next;


{

	struct cw buf;



	if (fread(&buf,sizeof(struct cw),1,fp) != 1)
	{
		fprintf(stderr, "unable to read from input pl\n");
		exit (1);
	}
	*next = buf.fwi;

	if (buf.mode == 0)
	{
		return("bcw");
	}
	else if (buf.mode == 8)
	{
		return("eor");
	}
	else if (buf.mode == 14)
	{
		return("eof");
	}
	else if (buf.mode == 15)
	{
		return("eod");
	}
	else
	{
		fprintf(stderr, "Invalid PL, dispose with DF=UNICOS\n");
		exit (1);
	}
}
