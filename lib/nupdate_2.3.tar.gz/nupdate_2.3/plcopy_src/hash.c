	static char USMID[] = "@(#)plcopy/hash.c	81.0	09/26/93 19:03:21";
/*	COPYRIGHT CRAY RESEARCH, INC.
 *	UNPUBLISHED -- ALL RIGHTS RESERVED UNDER
 *	THE COPYRIGHT LAWS OF THE UNITED STATES.
 */


long
hash(name,length)
char *name;
int length;


{


	long i, value;


	value = 0;
	for (i=0;i<length;i++)
		value = value+(long)name[i];
	return(value);
}
