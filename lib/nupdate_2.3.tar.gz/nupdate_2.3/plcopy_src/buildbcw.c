	static char USMID[] = "@(#)plcopy/buildbcw.c	81.0	09/26/93 19:03:21";
/*	COPYRIGHT CRAY RESEARCH, INC.
 *	UNPUBLISHED -- ALL RIGHTS RESERVED UNDER
 *	THE COPYRIGHT LAWS OF THE UNITED STATES.
 */
struct bcw
{
	unsigned mode:4;
	unsigned un1:16;
	unsigned un2:11;
#ifdef SUN
	unsigned bn1:1;
	unsigned bn2:23;
#else
	unsigned bn:24;
#endif
	unsigned fwi:9;
};

buildbcw(buffer,bn)
struct bcw buffer[];
long bn;

{
	buffer[0].mode = 0;
	buffer[0].un1 = 0;
	buffer[0].un2 = 0;
#ifdef SUN
	/*
		When running on the SUNs, the words need to be aligned
		on 32 bit boundaries, or they will force additional
		words being pulled in.  This forces the block number
		to be set in three parts
	*/
	buffer[0].bn1 = (bn>>23) & 0x1;
	buffer[0].bn2 = bn & 0x7FFFFF;
#else
	buffer[0].bn = bn;
#endif
	buffer[0].fwi = 0;
	return;
}
