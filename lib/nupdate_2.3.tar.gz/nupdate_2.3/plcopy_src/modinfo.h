/*	static char USMID "@(#)plcopy/modinfo.h	81.0	09/26/93 19:03:21"  */
/*	COPYRIGHT CRAY RESEARCH, INC.
 *	UNPUBLISHED -- ALL RIGHTS RESERVED UNDER
 *	THE COPYRIGHT LAWS OF THE UNITED STATES.
 */
struct list
{
	char *id;
	char *id2;
	char *deck;
	int offset;
	struct list *next;
};
