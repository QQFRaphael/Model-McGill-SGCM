	static char USMID[] = "@(#)plcopy/scmdep.c	81.0	09/26/93 19:03:21";
/*	COPYRIGHT CRAY RESEARCH, INC.
 *	UNPUBLISHED -- ALL RIGHTS RESERVED UNDER
 *	THE COPYRIGHT LAWS OF THE UNITED STATES.
 */
#include <stdio.h>
#include "modinfo.h"

char *
scmdep(id,seq,deck,qlen)
char *id, *seq, *deck;
int qlen;

{
	extern char *direct;
	extern struct list *modlist, *tail;

	char appchar, *modid, *modname, *res, *thisdeck, *tptr;
	char buffer[BUFSIZ], newseq[10];

	int appended, i, lastcomment, offset, skip;

	struct list *p;


	FILE *fp;



	res = 0;
	thisdeck = 0;
	lastcomment = 0;


	/*  Get the name of the file and check if it exists */
	modname = (char *)malloc(strlen(direct)+1+strlen(id)+1);
	strcpy(modname,direct);
	strcat(modname,"/");
	strcat(modname,id);
	modname[strlen(modname)-1] = '\0';

	/*  Determine if the mod is in the specified directory */
	fp = fopen(modname,"r");
	if (!fp)
	{
		free(modname);
		return(res);
	}

	/*  check the mod list to see if this mod was already processed */
	if (modlist)
	{
		/*  Search through the mod list for this id  */
		p = modlist;
		while (p)
		{
			if (strcmp(p->id,id)==0)
			{
				/*  This is the correct id, check the deck affected */
				if (strcmp(deck,p->deck) != 0)
				{
					/*  This id is not for this deck  */
					fprintf(stderr, "plcopy:  Error in mod %s\n",modname);
					fprintf(stderr, "         id %s changed %s, not %s\n",
						p->id,p->deck,deck);
					exit (1);
				}
				/*  Found the mod, add the offset to the sequence number  */
				res = (char *)malloc(strlen(id)+strlen(seq)+4);
				strcpy(res,id);
				res[strlen(res)-1] = '\0';
				strcat(res,".");
				i = atol(seq);
				i = i+p->offset;
				sprintf(newseq,"%d",i);
				strcat(res,newseq);
				(void) fclose(fp);
				free(modname);
				return(res);
			}
			p = p->next;
		}
	}


	/*  This modid has not been processed yet, read through the file and add ids */

	/*  Form the first scm id for this file  */
	modid = (char *)malloc(strlen(id)+1);
	strcpy(modid,id);
	appchar = 'a';
	appended = 0;
	modid[strlen(modid)-1] = appchar;

	if (!modlist)
	{
		modlist = (struct list *)malloc(sizeof(struct list));
		modlist->next = 0;
		p = modlist;
		tail = modlist;
	}
	else
	{
		tail->next = (struct list *)malloc(sizeof(struct list ));
		tail = tail->next;
		tail->next = 0;
		p = tail;
	}
	p->id = (char *)malloc(strlen(modid)+1);
	strcpy(p->id,modid);
	p->offset = 0;
	offset = 0;
	if (strcmp(modid,id)==0)
	{
		/*  This is the modid being searched for */
		res = (char *)malloc(strlen(id)+1+strlen(seq)+5);
		strcpy(res,id);
		res[strlen(res)-1] = '\0';
		strcat(res,".");
		strcat(res,seq);
	}


	/*  Read in up to the first *f or *n directive  */
	while (fgets(buffer,BUFSIZ,fp) != NULL &&
		 strncmp(buffer,"*f ",3) != 0 && strncmp(buffer,"*n ",3) != 0 &&
		 strncmp(buffer,"*f\t",3) != 0 && strncmp(buffer,"*n\t",3) != 0);

	if (strncmp(buffer,"*n ",3) == 0 || strncmp(buffer,"*n\t",3) == 0)
	{
		skip = 1;
	}
	else
	{
		skip = 0;
	}
	if (skip)
	{
		lastcomment = 0;
	}
	else
	{
		lastcomment = 1;
	}


	/*  Determine what this deck is  */
	tptr = &buffer[3];
	while (tptr[0] == ' ' || tptr[0] == '\t') tptr++;
	thisdeck = (char *)malloc(strlen(tptr)+1);
	tptr = tptr+qlen;
	strcpy(thisdeck,tptr);
	trim(thisdeck);
	p->deck = thisdeck;


	/*  Read in all ids from the mod, skipping *c and *m lines  */
	while (fgets(buffer,BUFSIZ,fp) != NULL)
	{
		if (strncmp(buffer,"*f ",3) == 0 || strncmp(buffer,"*f\t",3) == 0)
		{
			/*
				new *f directive, increase the app character
				and add an entry to modlist
			*/

			/*  Determine what this deck is  */
			lastcomment = 1 ;
			trim(buffer);
			tptr = &buffer[3];
			while (tptr[0] == ' ' || tptr[0] == '\t') tptr++;
			thisdeck = (char *)malloc(strlen(tptr)+1);
			tptr = tptr+qlen;
			strcpy(thisdeck,tptr);

			if (appchar == 'z')
			{
				if (!appended)
				{
					/*  Reset modid to a, and add one character  */
					modid[strlen(modid)-1] = 'a';
					appchar = 'a';
					modid = (char *)realloc(modid,strlen(modid)+2);
					modid[strlen(modid)+1] = '\0';
					modid[strlen(modid)] = appchar;
					appended = 1;
				}
				else
				{
					/*  Increase the value of the previous character  */
					appchar = modid[strlen(modid)-2];
					if (appchar == 'z')
					{
						fprintf(stderr, "plcopy:  Error, mod name overflow in %s\n",modid);
						exit (1);
					}
					appchar++;
					modid[strlen(modid)-2] = appchar;
					appchar = 'a';
					modid[strlen(modid)-1] = appchar;
				}

			}
			else
			{
				appchar++;
				modid[strlen(modid)-1] = appchar;
			}

			/*  Add this id to the list  */
			tail->next = (struct list *)malloc(sizeof(struct list));
			tail = tail->next;
			tail->next = 0;
			p = tail;
			p->offset = offset;
			p->id = (char *)malloc(strlen(modid)+1);
			strcpy(p->id,modid);
			p->deck = thisdeck;
			if (strcmp(modid,id)==0)
			{
				/*  This is the modid being searched for */
				if (strcmp(deck,thisdeck) != 0)
				{
					fprintf(stderr, "plcopy:  Error in mod %s\n",modname);
					fprintf(stderr, "         id %s changed %s, not %s\n",
						p->id,p->deck,deck);
					exit (1);
				}
				res = (char *)malloc(strlen(id)+1+strlen(seq)+5);
				strcpy(res,id);
				res[strlen(res)-1] = '\0';
				strcat(res,".");
				sprintf(newseq,"%d",atol(seq)+offset);
				strcat(res,newseq);
			}
			skip = 0;
		}
		else if (strncmp(buffer,"*n ",3) == 0 || strncmp(buffer,"*n\t",3) == 0)
		{
			/*
				new *n directive, increase the app character
				but don't add an entry to modlist
			*/
			if (appchar == 'z')
			{
				if (!appended)
				{
					/*  Reset modid to a, and add one character  */
					modid[strlen(modid)-1] = 'a';
					appchar = 'a';
					modid = (char *)realloc(modid,strlen(modid)+2);
					modid[strlen(modid)+1] = '\0';
					modid[strlen(modid)] = appchar;
					appended = 1;
				}
				else
				{
					/*  Increase the value of the previous character  */
					appchar = modid[strlen(modid)-2];
					if (appchar == 'z')
					{
						fprintf(stderr, "plcopy:  Error, mod name overflow in %s\n",modid);
						exit (1);
					}
					appchar++;
					modid[strlen(modid)-2] = appchar;
					appchar = 'a';
					modid[strlen(modid)-1] = appchar;
				}
			}
			else
			{
				appchar++;
				modid[strlen(modid)-1] = appchar;
			}
			skip = 1;
			lastcomment = 0;
		}
		else if (strncmp(buffer,"*m ",3)==0)
		{
			fprintf(stderr, "plcopy:  multiple *ms in mod %s\n",
				modname);
			exit (1);
		}
		else if (strncmp(buffer,"*c",2) != 0 &&
			 strncmp(buffer,"*i ",3) != 0 && strncmp(buffer,"*i\t",3) != 0 &&
			 strncmp(buffer,"*d ",3) != 0 && strncmp(buffer,"*d\t",3) != 0 &&
			 strncmp(buffer,"*b ",3) != 0 && strncmp(buffer,"*b\t",3) != 0)
		{
			/*  Increase offset by 1 if the last directive was not a comment  */
			if (!skip && !lastcomment) offset++;
		}
		else
		{
			lastcomment = 0;
		}
	}
	if (!res)
	{
		fprintf(stderr, "plcopy:  Error, id %s not found in mod %s\n",id,modname);
		exit (1);
	}
	(void) fclose(fp);
	free(modname);
	free(modid);
	return(res);
}
