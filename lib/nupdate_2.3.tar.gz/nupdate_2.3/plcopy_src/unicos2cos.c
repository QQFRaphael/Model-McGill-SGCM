	static char USMID[] = "@(#)plcopy/unicos2cos.c	81.0	09/26/93 19:03:21";
/*	COPYRIGHT CRAY RESEARCH, INC.
 *	UNPUBLISHED -- ALL RIGHTS RESERVED UNDER
 *	THE COPYRIGHT LAWS OF THE UNITED STATES.
 */
#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>

unicos2cos(inpl, outpl, makeold)
char *inpl, *outpl;
int makeold;

{

	/*
		This routine determines whether the unicos PL is a
		single format PL, or a directory format PL and calls
		the correct routine.
	*/

	struct stat status;




	if (stat(inpl,&status) != 0)
	{
		/*  The inpl does not exist  */
		fprintf(stderr, "plcopy: unable to open file %s\n",inpl);
		exit (1);
	}
	if ((status.st_mode & 0040000) == 0)
	{
		/*  The file is not a directory, it is a single file  */
		if (makeold)
		{
			newsf2old(inpl, outpl);
		}
		else
		{
			singlefile(inpl, outpl);
		}
	}
	else
	{
		/*  The file is a directory  */
		if (makeold)
		{
			newdir2old(inpl, outpl);
		}
		else
		{
			directory(inpl, outpl);
		}
	}
	return;
}
