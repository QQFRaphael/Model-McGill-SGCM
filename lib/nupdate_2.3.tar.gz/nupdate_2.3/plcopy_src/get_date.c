	static char USMID[] = "@(#)plcopy/get_date.c	81.0	09/26/93 19:03:21";
/*	COPYRIGHT CRAY RESEARCH, INC.
 *	UNPUBLISHED -- ALL RIGHTS RESERVED UNDER
 *	THE COPYRIGHT LAWS OF THE UNITED STATES.
 */
#include <sys/types.h>
#include <time.h>
get_date(date)
char *date;

{
	struct tm *mtm;
	long clock;
	extern struct tm *localtime();
	extern long time();

	clock = time(0);
	mtm = localtime(&clock);
	sprintf(date,"%.2d/%.2d/%.2d",mtm->tm_mon+1,
           mtm->tm_mday,mtm->tm_year);
	return;
}
