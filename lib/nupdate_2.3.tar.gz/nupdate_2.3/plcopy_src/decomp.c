	static char USMID[] = "@(#)plcopy/decomp.c	81.0	09/26/93 19:03:21";
/*	COPYRIGHT CRAY RESEARCH, INC.
 *	UNPUBLISHED -- ALL RIGHTS RESERVED UNDER
 *	THE COPYRIGHT LAWS OF THE UNITED STATES.
 */

decomp(notrunc,buff,outbuff)
int notrunc;
char *buff, *outbuff;


{

	char *tptr1, *tptr2;
	int i, num;




	tptr1 = buff;
	tptr2 = outbuff;


	while (tptr1[0] != '\0')
	{
		while (tptr1[0] != '\033' && tptr1[0] != '\0')
		{
			tptr2[0] = tptr1[0];
			tptr1++;
			tptr2++;
		}
		if (tptr1[0] == '\033')
		{
			tptr1++;
			num = (unsigned )tptr1[0] - 036;
			for (i=0;i<num;i++)
			{
				tptr2[0] = ' ';
				tptr2++;
			}
			tptr1++;
		}
	}
	tptr2[0] = '\0';
	if (!notrunc)
	{
		num = strlen(outbuff);
		while (outbuff[num-1] == ' ' && num>0)
		{
			tptr2--;
			tptr2[0] = '\0';
			num--;
		}
	}
	/*  Make sure that last word is all 0  */
	for (i=0;i<8;i++)
	{
		tptr2[0] = '\0';
		tptr2++;
	}
	return;
}
