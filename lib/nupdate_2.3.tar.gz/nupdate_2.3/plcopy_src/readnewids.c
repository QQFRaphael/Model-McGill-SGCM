	static char USMID[] = "@(#)plcopy/readnewids.c	81.0	09/26/93 19:03:21";
/*	COPYRIGHT CRAY RESEARCH, INC.
 *	UNPUBLISHED -- ALL RIGHTS RESERVED UNDER
 *	THE COPYRIGHT LAWS OF THE UNITED STATES.
 */
#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include "pltabs.h"

readnewids(tident,modids,numdecks,nummods,tidcnt,infp,inpl,next)
struct newidt **tident, **modids;
int *numdecks, *nummods, tidcnt, *next;
FILE *infp;
char *inpl;

{

	/*  This routine is responsible for reading in the new format
	    TIDENT table.  */

	char *cw;

	long ts;

	struct newidt tempid;

	extern char *getcw();




	/*  Allocate twice the space needed for the tident.  One is for the decks,
	    the other is for the mods  */
	*tident = (struct newidt *)malloc(tidcnt*sizeof(struct newidt));
	*modids = (struct newidt *)malloc(tidcnt*sizeof(struct newidt));
	*nummods = 0;
	*numdecks = 0;
	ts = time(0);
	while (tidcnt > 0)
	{
		if (*next>2)
		{
			/*  The entire next entry is before the next control word  */
			if (fread(tempid.part1.stuff,sizeof(struct newidt),1,infp) != 1)
			{
				fprintf(stderr, "plcopy:  unable to read from PL %s\n",inpl);
				exit (1);
			}
			*next = *next-3;
		}
		else if (*next == 2)
		{
			/*  The first two words of the TIDENT are followed by a control word  */
			if (fread(tempid.part1.stuff,8,2,infp) != 2)
			{
				fprintf(stderr, "plcopy:  unable to read from PL %s\n",inpl);
				exit (1);
			}
			cw = getcw(infp,next);
			if (strcmp(cw,"bcw") || *next < 1)
			{
				fprintf(stderr, "plcopy:  invalid control word in %s\n",inpl);
				exit (1);
			}
			if (fread(tempid.part3.stuff,8,1,infp) != 1)
			{
				fprintf(stderr, "plcopy:  unable to read from PL %s\n",inpl);
				exit (1);
			}
			*next = *next-1;
		}
		else if (*next == 1)
		{
			/*  The first word of the TIDENT is followed by a control word  */
			if (fread(tempid.part1.stuff,8,1,infp) != 1)
			{
				fprintf(stderr, "plcopy:  unable to read from PL %s\n",inpl);
				exit (1);
			}
			cw = getcw(infp,next);
			if (strcmp(cw,"bcw") || *next <= 1)
			{
				fprintf(stderr, "plcopy:  invalid control word in %s\n",inpl);
				exit (1);
			}
			if (fread(tempid.part2.stuff,8,2,infp) != 2)
			{
				fprintf(stderr, "plcopy:  unable to read from PL %s\n",inpl);
				exit (1);
			}
			*next = *next-2;
		}
		else
		{
			/*  There is a control word, followed the by tident entry  */
			cw = getcw(infp, next);
			if (strcmp(cw,"bcw") || *next <= 2)
			{
				fprintf(stderr, "plcopy:  invalid control word in %s\n",inpl);
				exit (1);
			}
			if (fread(tempid.part1.stuff,8,3,infp) != 3)
			{
				fprintf(stderr, "plcopy:  unable to read from PL %s\n",inpl);
				exit (1);
			}
			*next = *next-3;
		}
		tempid.part3.flags.timestamp = ts;
		if (tempid.part2.flags.type != 0)
		{
			/*  This is a deck, copy all information into tident[numdecks] */
			(*tident)[*numdecks] = tempid;
			*numdecks = *numdecks+1;
		}
		else
		{
			/*  This is a mod identifier, set to -1  */
			(*modids)[*nummods] = tempid;
			*nummods = *nummods+1;
		}
		tidcnt--;
	}
	return;
}
