	static char USMID[] = "@(#)plcopy/dir.c	81.0	09/26/93 19:03:21";
/*	COPYRIGHT CRAY RESEARCH, INC.
 *	UNPUBLISHED -- ALL RIGHTS RESERVED UNDER
 *	THE COPYRIGHT LAWS OF THE UNITED STATES.
 */
#include <sys/types.h>
#include <sys/stat.h>
int
dir(name)
char *name;
{
	struct stat status;
	if (stat(name,&status)!= 0)
	{
		return(0);
	}
	if ((status.st_mode & 0040000) == 0)
	{
		return(0);
	}
	return(1);
}
